<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_faq']['question'] = array('Otázka', 'Prosím vyplňte otázku.');
$GLOBALS['TL_LANG']['tl_faq']['alias'] = array('FAQ alias', 'Alias FAQ je jedinečný odkaz na otázku, který může být volán namísto ID otázky.');
$GLOBALS['TL_LANG']['tl_faq']['author'] = array('Autor', 'Vyberte autora.');
$GLOBALS['TL_LANG']['tl_faq']['answer'] = array('Odpověď', 'Prosím vyplňte odpověď.');
$GLOBALS['TL_LANG']['tl_faq']['addImage'] = array('Přidat obrázek', 'Přidat obrázek do odpovědi.');
$GLOBALS['TL_LANG']['tl_faq']['addEnclosure'] = array('Přidat přílohu', 'Přidat jednu neboo více příloh ke stažení.');
$GLOBALS['TL_LANG']['tl_faq']['enclosure'] = array('Příloha', 'Vyberte soubory, které chcete přiložit.');
$GLOBALS['TL_LANG']['tl_faq']['noComments'] = array('Vypnout komentáře', 'Nepovolit přidávání komentářů k tomuto FAQ.');
$GLOBALS['TL_LANG']['tl_faq']['published'] = array('Publikováno', 'FAQ nebude viditelný na vaší stránce dokud není publikován.');
$GLOBALS['TL_LANG']['tl_faq']['title_legend'] = 'Název a autor';
$GLOBALS['TL_LANG']['tl_faq']['answer_legend'] = 'Odpověď';
$GLOBALS['TL_LANG']['tl_faq']['image_legend'] = 'Nastavení obrázku';
$GLOBALS['TL_LANG']['tl_faq']['enclosure_legend'] = 'Přílohy';
$GLOBALS['TL_LANG']['tl_faq']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_faq']['publish_legend'] = 'Nastavení publikování';
$GLOBALS['TL_LANG']['tl_faq']['new'] = array('Nová otázka', 'Vytvořit novou otázku');
$GLOBALS['TL_LANG']['tl_faq']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k otázce s ID %s');
$GLOBALS['TL_LANG']['tl_faq']['edit'] = array('Editovat otázku', 'Editovat otázku s ID %s');
$GLOBALS['TL_LANG']['tl_faq']['copy'] = array('Zkopírovat otázku', 'Zkopíruje otázku s ID %s');
$GLOBALS['TL_LANG']['tl_faq']['cut'] = array('Přesunout otázku', 'Přesune otázku s ID %s');
$GLOBALS['TL_LANG']['tl_faq']['delete'] = array('Smazat otázku', 'Smazat otázku s ID %s');
$GLOBALS['TL_LANG']['tl_faq']['toggle'] = array('Publikovat / nepublikovat otázku', 'Publikovat / nepublikovat otázku ID %s');
$GLOBALS['TL_LANG']['tl_faq']['editheader'] = array('Upravit kategorii', 'Upravit tuto kategorii');
$GLOBALS['TL_LANG']['tl_faq']['pasteafter'] = array('Vložit na začátek', 'Vloží za otázku s ID %s');
$GLOBALS['TL_LANG']['tl_faq']['pastenew'] = array('Vytvořit novou otázku na začátek', 'Vytvořit novou otázku za otázku s ID %s');

?>