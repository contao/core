<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_faq_category']['title'] = array('Titulek', 'Vložte titulek kategorie.');
$GLOBALS['TL_LANG']['tl_faq_category']['headline'] = array('Záhlaví', 'Vložte záhlaví kategorie.');
$GLOBALS['TL_LANG']['tl_faq_category']['jumpTo'] = array('Přejít na stránku', 'Prosím vyberte stránku, na kterou budou přesměrováni návštěvníci, když kliknou na otázku.');
$GLOBALS['TL_LANG']['tl_faq_category']['allowComments'] = array('Povolit komentáře', 'Dovolí návštěvníkům přidávat komentáře k FAQ.');
$GLOBALS['TL_LANG']['tl_faq_category']['notify'] = array('Zaslat upozornění', 'Zvolte prosím osobu, která dostane vyrozumění mailem, že byl přidán komentář.');
$GLOBALS['TL_LANG']['tl_faq_category']['sortOrder'] = array('Řadit podle', 'Podle výchozího nastavení budou komentáře řazeny vzestupně, tedy od nejstaršího po nejnovější.');
$GLOBALS['TL_LANG']['tl_faq_category']['perPage'] = array('Počet komentářů na stránku', 'Počet komentářů na stránku. Zadejte 0, abyste jste vypli zalamování stránky.');
$GLOBALS['TL_LANG']['tl_faq_category']['moderate'] = array('Moderovat komentáře', 'Schvalování komentářů před jejich publikováním na webové stránce.');
$GLOBALS['TL_LANG']['tl_faq_category']['bbcode'] = array('Povolit BBCode', 'Umožnit návštěvníkům formátovat jejich komentáře pomocí BBCode.');
$GLOBALS['TL_LANG']['tl_faq_category']['requireLogin'] = array('Vyžadovat přihlášení pro přidávání komentářů', 'Povolit přidávat komentáře jen přihlášeným uživatelům.');
$GLOBALS['TL_LANG']['tl_faq_category']['disableCaptcha'] = array('Vypnout bezpečnostní otázku.', 'Použít tuto volbu jen tehdy, pokud smí přidávat komentáře jen autorizovaní uživatelé. V jiném případě je doporučeno nechat bezpečnostní otázku zapnutou.');
$GLOBALS['TL_LANG']['tl_faq_category']['tstamp'] = array('Datum změny', 'Čas a datum poslední změny');
$GLOBALS['TL_LANG']['tl_faq_category']['title_legend'] = 'Název a přesměrování';
$GLOBALS['TL_LANG']['tl_faq_category']['comments_legend'] = 'Komentáře';
$GLOBALS['TL_LANG']['tl_faq_category']['notify_admin'] = 'Administrátor systému';
$GLOBALS['TL_LANG']['tl_faq_category']['notify_author'] = 'Autor FAQ';
$GLOBALS['TL_LANG']['tl_faq_category']['notify_both'] = 'Autor a administrátor systému';
$GLOBALS['TL_LANG']['tl_faq_category']['deleteConfirm'] = 'Smazání kategorie odstraní také všechny její otázky! Opravdu chcete odstranit kategorii s ID %s?';
$GLOBALS['TL_LANG']['tl_faq_category']['new'] = array('Nová kategorie', 'Vytvoří novou kategorii');
$GLOBALS['TL_LANG']['tl_faq_category']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti ke kategorii s ID %s');
$GLOBALS['TL_LANG']['tl_faq_category']['edit'] = array('Upravit kategorii', 'Upraví kategorii s ID %s');
$GLOBALS['TL_LANG']['tl_faq_category']['editheader'] = array('Upravit nastavení kategorie', 'Upravit nastavení kategorie ID %s');
$GLOBALS['TL_LANG']['tl_faq_category']['copy'] = array('Zkopírovat kategorii', 'Zkopíruje kategorii s ID %s');
$GLOBALS['TL_LANG']['tl_faq_category']['delete'] = array('Smazat kategorii', 'Smazat kategorii s ID %s');

?>