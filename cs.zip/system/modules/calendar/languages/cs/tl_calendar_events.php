<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_calendar_events']['title'] = array('Název', 'Prosím zadejte název události.');
$GLOBALS['TL_LANG']['tl_calendar_events']['alias'] = array('Alias události', 'Alias události je jedinečný odkaz na tuto událost, který může být volán na místo ID události.');
$GLOBALS['TL_LANG']['tl_calendar_events']['author'] = array('Autor', 'Zde můžete změnit autora události');
$GLOBALS['TL_LANG']['tl_calendar_events']['addTime'] = array('Přidat čas', 'Přidejte čas začátku a konce události.');
$GLOBALS['TL_LANG']['tl_calendar_events']['startTime'] = array('Začátek události', 'Prosím zadejte čas začátku událosto podle celosvětového časového formátu.');
$GLOBALS['TL_LANG']['tl_calendar_events']['endTime'] = array('Konec události', 'Prosím zadejte čas konce události podle celosvětového časového formátu');
$GLOBALS['TL_LANG']['tl_calendar_events']['startDate'] = array('Datum začátku', 'Prosím zadejte datum začátku události.');
$GLOBALS['TL_LANG']['tl_calendar_events']['endDate'] = array('Datum konce', 'Prosím zadejte datum konce události nebo nechte prázdné pro jednodenní událost.');
$GLOBALS['TL_LANG']['tl_calendar_events']['teaser'] = array('Ukázka události', 'Ukázka události se běžně zobrazuje místo celého obsahu dané události, pokud se na stránce zobrazí víc události najednou. Ukázka je pak ukončená odkazem "Číst celé..."');
$GLOBALS['TL_LANG']['tl_calendar_events']['details'] = array('Text události', 'Prosím zadejte text události.');
$GLOBALS['TL_LANG']['tl_calendar_events']['addImage'] = array('Přidat obrázek', 'Pokud zvolíte tuto možnost, obrázek bude přidán k události.');
$GLOBALS['TL_LANG']['tl_calendar_events']['recurring'] = array('Opakující se událost', 'Opakovat tuto událost.');
$GLOBALS['TL_LANG']['tl_calendar_events']['repeatEach'] = array('Interval', 'Prosím nastavte časový interval opakováních.');
$GLOBALS['TL_LANG']['tl_calendar_events']['recurrences'] = array('Opakování', 'Prosím nastavte počet opakování (0 = nekonečno).');
$GLOBALS['TL_LANG']['tl_calendar_events']['addEnclosure'] = array('Přidat přílohu', 'Přidat jeden nebo více stažitelných souborů k události.');
$GLOBALS['TL_LANG']['tl_calendar_events']['enclosure'] = array('Přílohy', 'Prosím zvolte soubory které chcete přiložit.');
$GLOBALS['TL_LANG']['tl_calendar_events']['source'] = array('Cíl přesměrování', 'Odkaz na interní nebo externí stránku místo výchozí stránky.');
$GLOBALS['TL_LANG']['tl_calendar_events']['default'] = array('Použít výchozí', 'Kliknutím na "Číst celé..." budou uživatelé přesměrováni na výchozí stránku kalendáře.');
$GLOBALS['TL_LANG']['tl_calendar_events']['internal'] = array('Stránka', 'Kliknutím na "Číst celé..." budou uživatelé přesměrováni na interní stránku.');
$GLOBALS['TL_LANG']['tl_calendar_events']['article'] = array('Na článek', 'Při kliknutí na "čti více" budou návštěvníci přesměrování na daný článek.');
$GLOBALS['TL_LANG']['tl_calendar_events']['external'] = array('Externí URL', 'Kliknutím na "Číst celé..." budou uživatelé přesměrováni na externí stránku.');
$GLOBALS['TL_LANG']['tl_calendar_events']['jumpTo'] = array('Stránka přesměrování', 'Prosím zadejte stránku na kterou bude návštěvník přesměrován.');
$GLOBALS['TL_LANG']['tl_calendar_events']['articleId'] = array('Článek', 'Zvolte prosím článek, na nějž budou přesměrování návštěvníci po kliknutí na danou událost.');
$GLOBALS['TL_LANG']['tl_calendar_events']['cssClass'] = array('Styl CSS', 'Zde můžete zadat jeden nebo více stylů CSS.');
$GLOBALS['TL_LANG']['tl_calendar_events']['noComments'] = array('Vypnout komentáře', 'Zakázat přidávání komentářů.');
$GLOBALS['TL_LANG']['tl_calendar_events']['published'] = array('Publikovat', 'Dokud nebude tato událost publikována, nezobrazí se na vašem webu');
$GLOBALS['TL_LANG']['tl_calendar_events']['start'] = array('Zobrazit od', 'Nezobrazit danou událost na webových stránkách před tímto dnem.');
$GLOBALS['TL_LANG']['tl_calendar_events']['stop'] = array('Zobrazit do', 'Nezobrazit danou událost na webových stránkách po tomto dni.');
$GLOBALS['TL_LANG']['tl_calendar_events']['title_legend'] = 'Název a autor';
$GLOBALS['TL_LANG']['tl_calendar_events']['date_legend'] = 'Datum a čas';
$GLOBALS['TL_LANG']['tl_calendar_events']['teaser_legend'] = 'Ukázka';
$GLOBALS['TL_LANG']['tl_calendar_events']['text_legend'] = 'Text události';
$GLOBALS['TL_LANG']['tl_calendar_events']['image_legend'] = 'Nastavení obrázku';
$GLOBALS['TL_LANG']['tl_calendar_events']['recurring_legend'] = 'Opakování';
$GLOBALS['TL_LANG']['tl_calendar_events']['enclosure_legend'] = 'Přílohy';
$GLOBALS['TL_LANG']['tl_calendar_events']['source_legend'] = 'Cíl přesměrování';
$GLOBALS['TL_LANG']['tl_calendar_events']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_calendar_events']['publish_legend'] = 'Nastavení publikování';
$GLOBALS['TL_LANG']['tl_calendar_events']['days'] = 'den(dny)';
$GLOBALS['TL_LANG']['tl_calendar_events']['weeks'] = 'týden(týdny)';
$GLOBALS['TL_LANG']['tl_calendar_events']['months'] = 'měsíc(měsíce)';
$GLOBALS['TL_LANG']['tl_calendar_events']['years'] = 'rok(y)';
$GLOBALS['TL_LANG']['tl_calendar_events']['new'] = array('Nová událost', 'Vytvořit novou událost');
$GLOBALS['TL_LANG']['tl_calendar_events']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k události ID %s');
$GLOBALS['TL_LANG']['tl_calendar_events']['edit'] = array('Upravit událost', 'Upravit událost ID %s');
$GLOBALS['TL_LANG']['tl_calendar_events']['copy'] = array('Kopírovat událost', 'Kopírovat událost ID %s');
$GLOBALS['TL_LANG']['tl_calendar_events']['cut'] = array('Přesunout událost', 'Přesunout událost ID %s');
$GLOBALS['TL_LANG']['tl_calendar_events']['delete'] = array('Smazat událost', 'Smazat událost ID %s');
$GLOBALS['TL_LANG']['tl_calendar_events']['toggle'] = array('Publikovat / nepublikovat', 'Publikovat / nepublikovat událost ID %s');
$GLOBALS['TL_LANG']['tl_calendar_events']['editheader'] = array('Upravit kalendář', 'Editovat tento kalendář');
$GLOBALS['TL_LANG']['tl_calendar_events']['pasteafter'] = array('Vložit do tohto kalenáře', 'Vložit za událost ID %s');

?>