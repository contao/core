<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_calendar']['title'] = array('Název', 'Prosím zadejte název kalendáře');
$GLOBALS['TL_LANG']['tl_calendar']['jumpTo'] = array('Stránka přesměrování', 'Prosím zvolte stránku, na kterou budou přesměrování návštěvníci po kliknutí na událost.');
$GLOBALS['TL_LANG']['tl_calendar']['allowComments'] = array('Povolit komentáře', 'Dovolí návštěvníkům komentovat události.');
$GLOBALS['TL_LANG']['tl_calendar']['notify'] = array('Zaslání zprávy', 'Zadejte prosím osoby oddělené čárkou, které dostanou zprávu, když bude vložen komentář.');
$GLOBALS['TL_LANG']['tl_calendar']['sortOrder'] = array('Třídit podle', 'Podle výchozího nastavení se na prvním místě zobrazí nejnovější komentáře.');
$GLOBALS['TL_LANG']['tl_calendar']['perPage'] = array('Počet komentářů na stránku', 'Počet komentářů na stránku. Použitím 0 se vypne zalamování stránky.');
$GLOBALS['TL_LANG']['tl_calendar']['moderate'] = array('Moderace komentářů', 'Povolování komentářů před zveřejněním.');
$GLOBALS['TL_LANG']['tl_calendar']['bbcode'] = array('Povolit BBCode', 'Dovolí návštěvníkům formátovat jejich komentáře pomocí BBCode.');
$GLOBALS['TL_LANG']['tl_calendar']['requireLogin'] = array('Vyžadovat přihlášení k přidání komentářů', 'Dovolí napsat komentáře jen registrovaným uživatelům.');
$GLOBALS['TL_LANG']['tl_calendar']['disableCaptcha'] = array('Vypnout bezpečnostní otázku', 'Zvolte tuto možnost jen tehdy, pokud jste povolili komentáře jen užšímu okruhu uživatelů.');
$GLOBALS['TL_LANG']['tl_calendar']['protected'] = array('Chránit kalendář', 'Zobrazit údalost pouze určitému členu skupiny.');
$GLOBALS['TL_LANG']['tl_calendar']['groups'] = array('Povolení členové skupiny', 'Zde můžete vybrat skupiny, kterým bude povoleno vidět tuto událost.');
$GLOBALS['TL_LANG']['tl_calendar']['makeFeed'] = array('Vytvoření kanálu RSS', 'Vytvoří RSS z údajů v kalendáři.');
$GLOBALS['TL_LANG']['tl_calendar']['format'] = array('Formát kanálu RSS', 'Zvolte prosím formát RSS.');
$GLOBALS['TL_LANG']['tl_calendar']['language'] = array('Jazyk', 'Prosím vložte jazyk podle RFC3066 formátu (např. <em>en</em>, <em>en-us</em> nebo <em>en-cockney</em>).');
$GLOBALS['TL_LANG']['tl_calendar']['source'] = array('Nastavení exportu', 'Zde můžete nastavit, co se má exportovat.');
$GLOBALS['TL_LANG']['tl_calendar']['maxItems'] = array('Maximální počet položek', 'Omezit počet exportovaných položek. Ponechte prázdné nebo vložte 0 pro zahrnutí všech.');
$GLOBALS['TL_LANG']['tl_calendar']['feedBase'] = array('Základní URL', 'Prosím zadejte základní URL obsahující protokol (např. <em>http://</em>).');
$GLOBALS['TL_LANG']['tl_calendar']['alias'] = array('Přezdívka kanálu RSS', 'Zde můžete zadat název souboru (bez diakritiky). Soubor XML se vytvoří automaticky v kořenovém adresáři Vaší verze TYPOlight (např. <em>zpravy.xml</em>');
$GLOBALS['TL_LANG']['tl_calendar']['description'] = array('Popis', 'Prosím zadejte krátký popis kalendáře');
$GLOBALS['TL_LANG']['tl_calendar']['tstamp'] = array('Datum revize', 'Datum a čas poslední revize');
$GLOBALS['TL_LANG']['tl_calendar']['title_legend'] = 'Název a cílová stránka';
$GLOBALS['TL_LANG']['tl_calendar']['comments_legend'] = 'Komentáře';
$GLOBALS['TL_LANG']['tl_calendar']['protected_legend'] = 'Omezený přístup';
$GLOBALS['TL_LANG']['tl_calendar']['feed_legend'] = 'Kanál RSS';
$GLOBALS['TL_LANG']['tl_calendar']['notify_admin'] = 'Adminstrátor systému';
$GLOBALS['TL_LANG']['tl_calendar']['notify_author'] = 'Autor události';
$GLOBALS['TL_LANG']['tl_calendar']['notify_both'] = 'Autor a správce systému';
$GLOBALS['TL_LANG']['tl_calendar']['source_teaser'] = 'Ukázka událostí';
$GLOBALS['TL_LANG']['tl_calendar']['source_text'] = 'Plné znění';
$GLOBALS['TL_LANG']['tl_calendar']['new'] = array('Nový kalendář', 'Vytvořit nový kalendář');
$GLOBALS['TL_LANG']['tl_calendar']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti ke kalendáři ID %s');
$GLOBALS['TL_LANG']['tl_calendar']['edit'] = array('Editovat kalendář', 'Editovat kalendář ID %s');
$GLOBALS['TL_LANG']['tl_calendar']['editheader'] = array('Upravit nastavení kalendáře', 'Upraví nastavení kalendáře ID %s');
$GLOBALS['TL_LANG']['tl_calendar']['copy'] = array('Kopírovat kalendář', 'Kopírovat kalendář ID %s');
$GLOBALS['TL_LANG']['tl_calendar']['delete'] = array('Smazat kalendář', 'Smazat kalendář ID %s');

?>