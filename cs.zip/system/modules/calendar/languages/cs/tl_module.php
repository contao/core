<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_module']['cal_calendar'] = array('Kalendáře', 'Prosím vyberte jeden nebo více kalendářů.');
$GLOBALS['TL_LANG']['tl_module']['cal_noSpan'] = array('Zkrácené zobrazení', 'Zobrazit události jen jednou, pokud se konají několik dnů po sobě.');
$GLOBALS['TL_LANG']['tl_module']['cal_startDay'] = array('První den týdne', 'Prosím zvolte první den v týdnu');
$GLOBALS['TL_LANG']['tl_module']['cal_format'] = array('Formát seznamu událostí', 'Zde můžete zvolit formát seznamu událostí.');
$GLOBALS['TL_LANG']['tl_module']['cal_ignoreDynamic'] = array('Ignorovat nastavené parametry URL', 'Neměnit časové období, které je založené na parametrech URL zadaných pro datum / měsíc / rok.');
$GLOBALS['TL_LANG']['tl_module']['cal_order'] = array('Třídit podle', 'Zde můžete zvolit, jakým způsobem se mají události třídit.');
$GLOBALS['TL_LANG']['tl_module']['cal_readerModule'] = array('Modul čtečka událostí', 'Automaticky přepne na události, pokud událost byla vybrána.');
$GLOBALS['TL_LANG']['tl_module']['cal_limit'] = array('Počet událostí', 'Zde můžete omezit počet zobrazených události. Zadejte 0 pro zobrazení všech.');
$GLOBALS['TL_LANG']['tl_module']['cal_template'] = array('Šablona událostí', 'Prosím zvolte šablonu události. Můžete si přidat vlastní šablonu do složky <em>templates</em>. Soubory šablon pro události začínají na <em>event_</em> a vyžadují příponu souboru <em>.tpl</em>.');
$GLOBALS['TL_LANG']['tl_module']['cal_ctemplate'] = array('Předloha kalendáře', 'Zde můžete vybrat předlohu kalendáře.');
$GLOBALS['TL_LANG']['tl_module']['cal_showQuantity'] = array('Zobrazit počet událostí', 'Zobrazit počet událostí vybraného měsíce');
$GLOBALS['TL_LANG']['tl_module']['cal_list'] = 'Seznam událostí';
$GLOBALS['TL_LANG']['tl_module']['cal_day'] = 'Den';
$GLOBALS['TL_LANG']['tl_module']['cal_month'] = 'Měsíc';
$GLOBALS['TL_LANG']['tl_module']['cal_year'] = 'Rok';
$GLOBALS['TL_LANG']['tl_module']['cal_all'] = 'Všechny události';
$GLOBALS['TL_LANG']['tl_module']['cal_upcoming'] = 'Nadcházející události';
$GLOBALS['TL_LANG']['tl_module']['next_7'] = '+ 1 týden';
$GLOBALS['TL_LANG']['tl_module']['next_14'] = '+ 2 týdny';
$GLOBALS['TL_LANG']['tl_module']['next_30'] = '+ 1 měsíc';
$GLOBALS['TL_LANG']['tl_module']['next_90'] = '+ 3 měsíce';
$GLOBALS['TL_LANG']['tl_module']['next_180'] = '+ 6 mesíců';
$GLOBALS['TL_LANG']['tl_module']['next_365'] = '+ 1 rok';
$GLOBALS['TL_LANG']['tl_module']['next_two'] = '+ 2 roky';
$GLOBALS['TL_LANG']['tl_module']['next_cur_month'] = 'na aktuální měsíc';
$GLOBALS['TL_LANG']['tl_module']['next_cur_year'] = 'na aktuální rok';
$GLOBALS['TL_LANG']['tl_module']['next_all'] = 'Všechny nadcházející události';
$GLOBALS['TL_LANG']['tl_module']['cal_past'] = 'Proběhlé události';
$GLOBALS['TL_LANG']['tl_module']['past_7'] = '- 1 týden';
$GLOBALS['TL_LANG']['tl_module']['past_14'] = '- 2 týdny';
$GLOBALS['TL_LANG']['tl_module']['past_30'] = '- 1 měsíc';
$GLOBALS['TL_LANG']['tl_module']['past_90'] = '- 3 měsíce';
$GLOBALS['TL_LANG']['tl_module']['past_180'] = '- 6 měsíců';
$GLOBALS['TL_LANG']['tl_module']['past_365'] = '- 1 rok';
$GLOBALS['TL_LANG']['tl_module']['past_two'] = '- 2 roky';
$GLOBALS['TL_LANG']['tl_module']['past_cur_month'] = 'na aktuální měsíc';
$GLOBALS['TL_LANG']['tl_module']['past_cur_year'] = 'na aktuální rok';
$GLOBALS['TL_LANG']['tl_module']['past_all'] = 'Všechny proběhlé události';

?>