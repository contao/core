<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_comments']['source'] = array('Původ', 'Tabulka, odkud pochází.');
$GLOBALS['TL_LANG']['tl_comments']['parent'] = array('ID rodičovského elementu', 'K tomu náležící rodičovský záznam.');
$GLOBALS['TL_LANG']['tl_comments']['date'] = array('Datum', 'Prosím zadejte datum komentáře.');
$GLOBALS['TL_LANG']['tl_comments']['name'] = array('Jméno', 'Prosím zadejte skutečné jméno autora.');
$GLOBALS['TL_LANG']['tl_comments']['email'] = array('E-mailová adresa', 'Prosím zadejte e-mailovou adresu autora (nebude publikována).');
$GLOBALS['TL_LANG']['tl_comments']['website'] = array('Web', 'Prosím zadejte volitelnou adresu webu.');
$GLOBALS['TL_LANG']['tl_comments']['comment'] = array('Komentář', 'Prosím zadejte komentář.');
$GLOBALS['TL_LANG']['tl_comments']['addReply'] = array('Odpovědět na komentář', 'Sem můžete odpověď na daný komentář.');
$GLOBALS['TL_LANG']['tl_comments']['author'] = array('Autor', 'Zde můžete změnit autora odpovědi.');
$GLOBALS['TL_LANG']['tl_comments']['reply'] = array('Odpověď', 'Sem můžete zadat Vaši odpověď.');
$GLOBALS['TL_LANG']['tl_comments']['published'] = array('Publikováno', 'Pouze publikované komentáře budou zobrazeny na webu.');
$GLOBALS['TL_LANG']['tl_comments']['author_legend'] = 'Autor';
$GLOBALS['TL_LANG']['tl_comments']['comment_legend'] = 'Komentář';
$GLOBALS['TL_LANG']['tl_comments']['reply_legend'] = 'Odpověď';
$GLOBALS['TL_LANG']['tl_comments']['publish_legend'] = 'Nastavení publikování';
$GLOBALS['TL_LANG']['tl_comments']['approved'] = 'Schváleno';
$GLOBALS['TL_LANG']['tl_comments']['pending'] = 'Čeká na schválení';
$GLOBALS['TL_LANG']['tl_comments']['tl_content'] = 'Článek';
$GLOBALS['TL_LANG']['tl_comments']['tl_page'] = 'Stránka';
$GLOBALS['TL_LANG']['tl_comments']['tl_news'] = 'Příspěvek novinky';
$GLOBALS['TL_LANG']['tl_comments']['tl_faq'] = 'FAQ';
$GLOBALS['TL_LANG']['tl_comments']['tl_calendar_events'] = 'Událost';
$GLOBALS['TL_LANG']['tl_comments']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti ke komentáři ID %s');
$GLOBALS['TL_LANG']['tl_comments']['edit'] = array('Upravit komentář', 'Upravit komentář ID %s');
$GLOBALS['TL_LANG']['tl_comments']['delete'] = array('Smazat komentář', 'Smazat komentář ID %s');
$GLOBALS['TL_LANG']['tl_comments']['toggle'] = array('Publikovat / nepublikovat komentář', 'Publikovat / nepublikovat komentář ID %s');

?>