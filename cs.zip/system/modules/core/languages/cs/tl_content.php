<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_content']['invisible'] = array('Neviditelný', 'Skrýt tento element na Vašem webu.');
$GLOBALS['TL_LANG']['tl_content']['type'] = array('Typ elementu', 'Zvolte typ obsahového elementu.');
$GLOBALS['TL_LANG']['tl_content']['headline'] = array('Nadpis', 'Zde můžete přidat nadpis k obsahovému elementu.');
$GLOBALS['TL_LANG']['tl_content']['text'] = array('Text', 'Můžete použít HTML tagy pro formátování textu.');
$GLOBALS['TL_LANG']['tl_content']['addImage'] = array('Přidat obrázek', 'Přidat obrázek k obsahovému elementu.');
$GLOBALS['TL_LANG']['tl_content']['singleSRC'] = array('Zdrojový soubor', 'Vyberte soubor a adresář');
$GLOBALS['TL_LANG']['tl_content']['alt'] = array('Alternativní text', 'V zajmu toho udělat obrázek nebo video přístupný můžete poskytnout alternativní text s krátkým popisem jejich obsahu.');
$GLOBALS['TL_LANG']['tl_content']['title'] = array('Název', 'Zde můžete přidat název obrázku (<em>název</em> atribut).');
$GLOBALS['TL_LANG']['tl_content']['size'] = array('Šířka a výška obrázku', 'Zadejte šířku, výšku nebo oboje velikosti za účelem změny velikosti. Pokud necháte toto pole prázdné bude zobrazena originální velikost.');
$GLOBALS['TL_LANG']['tl_content']['imagemargin'] = array('Okraj obrázku', 'Zadejte horní, pravý, spodní a levý okraj a jednotku. Okraj obrázku je místo mezi ním a jeho nejbližším sousedním elementem.');
$GLOBALS['TL_LANG']['tl_content']['imageUrl'] = array('Použít obrázek jako odkaz', 'Vlastní odkaz přepíše odkaz lightboxu, tudíž se pak nebude moct obrázek zobrazit v plné velikosti.');
$GLOBALS['TL_LANG']['tl_content']['fullsize'] = array('Zobrazit celou velikost', 'Pokud zvolíte tuto volbu obrázek bude možné po kliknutí vidět obrázek v plné velikosti.');
$GLOBALS['TL_LANG']['tl_content']['floating'] = array('Zarovnání obrázku', 'Vyberte zarovnání obrázku. Obrázek může být zobrazen pod textem nebo na pravé či levé straně textu.');
$GLOBALS['TL_LANG']['tl_content']['caption'] = array('Titulek obrázku', 'Pokud zadáte alternativní text sem, bude zobrazen pod obrázkem. Nechte toto pole prázdné k vypnutí této vlastnosti.');
$GLOBALS['TL_LANG']['tl_content']['html'] = array('HTML kód', 'Seznam povolených HTML tagů můžete upravit v nastavení.');
$GLOBALS['TL_LANG']['tl_content']['listtype'] = array('Typ seznamu', 'Vyberte prosím typ seznamu.');
$GLOBALS['TL_LANG']['tl_content']['listitems'] = array('Seznam položek', 'Pokud je vypnutý JavaScript, ujistěte se, že jste uložili změny před tím, než začnete měnit pořadí.');
$GLOBALS['TL_LANG']['tl_content']['tableitems'] = array('Položky tabulky', 'Pokud je vypnutý JavaScript, ujistěte se, že jste uložili změny před tím, než začnete měnit pořadí.');
$GLOBALS['TL_LANG']['tl_content']['summary'] = array('Tabulka (souhrnné informace)', 'Zadejte prosím souhrn obsahu a struktury tabulky.');
$GLOBALS['TL_LANG']['tl_content']['thead'] = array('Přidat záhlaví', 'První řádek tabulky nastavit jako záhlaví.');
$GLOBALS['TL_LANG']['tl_content']['tfoot'] = array('Přidat zápatí', 'Poslední řádek tabulky nastavit jako zápatí.');
$GLOBALS['TL_LANG']['tl_content']['tleft'] = array('Přidat nadpisy v řadách', 'Použít poslední řadu tabulky jako zápatí.');
$GLOBALS['TL_LANG']['tl_content']['sortable'] = array('Seřaditelná tabulka', 'Umožní řazení dat v tabulce (musí být aktivní JavaScript a záhlaví tabulky).');
$GLOBALS['TL_LANG']['tl_content']['sortIndex'] = array('Výchozí řazení', 'Počet výchozích sloupců, podle nichž proběhne třídění.');
$GLOBALS['TL_LANG']['tl_content']['sortOrder'] = array('Třídit podle', 'Zvolte prosím pořadí třídení.');
$GLOBALS['TL_LANG']['tl_content']['mooType'] = array('Operační mód', 'Vyberte prosím operační mód elementu akordeon.');
$GLOBALS['TL_LANG']['tl_content']['single'] = array('Jednoduchý element', 'Má vlastnosti jako samostatný textový element uvnitř části akordeonu.');
$GLOBALS['TL_LANG']['tl_content']['start'] = array('Začátek lišty akordeonu', 'Označí začátek lišty akordeonum, která může obsahovat několik obsahových elementů.');
$GLOBALS['TL_LANG']['tl_content']['stop'] = array('Konec lišty akordeonu', 'Označí konec lišty akordeonu, která může obsahovat několik obsahových elementů.');
$GLOBALS['TL_LANG']['tl_content']['mooHeadline'] = array('Záhlaví', 'Zadejte prosím záhlaví obsahu. Jsou povelené značky HTML.');
$GLOBALS['TL_LANG']['tl_content']['mooStyle'] = array('CSS', 'Zde můžete zadat pro tento element kaskádovitý styl.');
$GLOBALS['TL_LANG']['tl_content']['mooClasses'] = array('Jméno třídy', 'Ponecháte-li toto políčko prázdné, bude použito výchozího nastavení. V jiném případě zadejte prosím vlastní třídu kaskádovitého stylu.');
$GLOBALS['TL_LANG']['tl_content']['shClass'] = array('Nastavení', 'Zde můžete upravit syntax highlinghter (např. <em>gutter: false;</em>).');
$GLOBALS['TL_LANG']['tl_content']['highlight'] = array('Zvýraznit syntax', 'Zadejte skriptovací jazyk');
$GLOBALS['TL_LANG']['tl_content']['code'] = array('Kód', 'Zadejte kód');
$GLOBALS['TL_LANG']['tl_content']['linkTitle'] = array('Název odkazu', 'Text odkazu se zobrazí namísto běžné adresy odkazu.');
$GLOBALS['TL_LANG']['tl_content']['embed'] = array('Zabudovaný odkaz', 'Použijte umisťovač "%s" na začlenění odkazu do textu (např. <em>více informací najdete %s</em>).');
$GLOBALS['TL_LANG']['tl_content']['rel'] = array('Lightbox', 'Chcete-li odkaz zobrazit v okně lightboxu, zadejte prosím příslušný atribut (např. "mediabox" nebo "lightbox")');
$GLOBALS['TL_LANG']['tl_content']['useImage'] = array('Obrázek jako odkaz', 'Použít obrázek namísto běžného odkazu.');
$GLOBALS['TL_LANG']['tl_content']['multiSRC'] = array('Zdrojové soubory', 'Vyberte prosím jeden nebo více souborů z úložny souborů. Zaškrtnutím složky se automaticky vyberou všechny v soubory, které se v ní nachází.');
$GLOBALS['TL_LANG']['tl_content']['useHomeDir'] = array('Domovský adresář', 'Použít domovský adresář jako zdroj dat, když se přihlášil jeden z členů.');
$GLOBALS['TL_LANG']['tl_content']['perRow'] = array('Náhledů na řádek', 'Počet náhledů obrázků na řádku.');
$GLOBALS['TL_LANG']['tl_content']['perPage'] = array('Položek na stránku', 'Počet elementů na stránku. Uvedením 0 se deaktivuje automatické zalomení.');
$GLOBALS['TL_LANG']['tl_content']['numberOfItems'] = array('Celkový počet obrazků', 'Zde můžete obezit celkový počet obrázků. Nastavte na 0 pro zobrazení všech');
$GLOBALS['TL_LANG']['tl_content']['sortBy'] = array('Řadit dle', 'Zvolte prosím pořadí třídění.');
$GLOBALS['TL_LANG']['tl_content']['galleryTpl'] = array('Šablona obrázkové galerie', 'Zde můžete zvolit šablonu pro obrázkovou galerii');
$GLOBALS['TL_LANG']['tl_content']['cteAlias'] = array('ID elementu', 'Vyberte ID elementu do kterého chcete vkládat');
$GLOBALS['TL_LANG']['tl_content']['articleAlias'] = array('Vztahující se článek', 'Zvolte prosím článek, který chcete vložit.');
$GLOBALS['TL_LANG']['tl_content']['article'] = array('ID článku', 'Vyberte ID článku který chcete zobrazit');
$GLOBALS['TL_LANG']['tl_content']['form'] = array('Formulář', 'Zvolte prosím požadovaný formulář.');
$GLOBALS['TL_LANG']['tl_content']['module'] = array('Modul', 'Zvolte prosím požadovaný modul.');
$GLOBALS['TL_LANG']['tl_content']['protected'] = array('Chránit element', 'Zobrazit element pouze členům skupiny');
$GLOBALS['TL_LANG']['tl_content']['groups'] = array('Povolené skupiny', 'Zde můžete zvolit, kterým skupinám bude povoleno vydět element');
$GLOBALS['TL_LANG']['tl_content']['guests'] = array('Ukázat pouze hostum', 'Skrýt element pokud je člen přihlášen');
$GLOBALS['TL_LANG']['tl_content']['cssID'] = array('Kaskádový styl ID a třída', 'Zde můžete zadat ID nebo jednu či více tříd kaskádovitých stylů.');
$GLOBALS['TL_LANG']['tl_content']['space'] = array('Místo před a po', 'Zadejte mezeru před a po elementu v pixelech');
$GLOBALS['TL_LANG']['tl_content']['type_legend'] = 'Typ elementu';
$GLOBALS['TL_LANG']['tl_content']['text_legend'] = 'Text/HTML/kód';
$GLOBALS['TL_LANG']['tl_content']['image_legend'] = 'Nastavení obrázku';
$GLOBALS['TL_LANG']['tl_content']['list_legend'] = 'Záznamy seznamu';
$GLOBALS['TL_LANG']['tl_content']['table_legend'] = 'Záznamy tabulky';
$GLOBALS['TL_LANG']['tl_content']['tconfig_legend'] = 'Nastavení tabulky';
$GLOBALS['TL_LANG']['tl_content']['sortable_legend'] = 'Možnosti třídění';
$GLOBALS['TL_LANG']['tl_content']['moo_legend'] = 'Nastavení akordeonu';
$GLOBALS['TL_LANG']['tl_content']['link_legend'] = 'Nastavení odkazů';
$GLOBALS['TL_LANG']['tl_content']['imglink_legend'] = 'Nastavení odkazu obrázku';
$GLOBALS['TL_LANG']['tl_content']['source_legend'] = 'Soubory a adresáře';
$GLOBALS['TL_LANG']['tl_content']['dwnconfig_legend'] = 'Nastavení stahování';
$GLOBALS['TL_LANG']['tl_content']['include_legend'] = 'Nastavení ikluziv';
$GLOBALS['TL_LANG']['tl_content']['protected_legend'] = 'Chráněný přístup';
$GLOBALS['TL_LANG']['tl_content']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_content']['template_legend'] = 'Předloha komentáře';
$GLOBALS['TL_LANG']['tl_content']['ordered'] = 'číselný seznam';
$GLOBALS['TL_LANG']['tl_content']['unordered'] = 'nečíselný seznam';
$GLOBALS['TL_LANG']['tl_content']['name_asc'] = 'Jména souboru (vzestupně)';
$GLOBALS['TL_LANG']['tl_content']['name_desc'] = 'Jména souboru (sestupně)';
$GLOBALS['TL_LANG']['tl_content']['date_asc'] = 'Data (vzestupně)';
$GLOBALS['TL_LANG']['tl_content']['date_desc'] = 'Data (sestupně)';
$GLOBALS['TL_LANG']['tl_content']['meta'] = 'souboru meta (meta.txt)';
$GLOBALS['TL_LANG']['tl_content']['random'] = 'náhodného pořadí';
$GLOBALS['TL_LANG']['tl_content']['new'] = array('Nový element', 'Vytvořit nový element');
$GLOBALS['TL_LANG']['tl_content']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k elementu ID %s');
$GLOBALS['TL_LANG']['tl_content']['cut'] = array('Přesunout element', 'Přesunout element ID %s');
$GLOBALS['TL_LANG']['tl_content']['copy'] = array('Kopírovat element', 'Kopírovat element ID %s');
$GLOBALS['TL_LANG']['tl_content']['delete'] = array('Smazat element', 'Smazat element ID %s');
$GLOBALS['TL_LANG']['tl_content']['edit'] = array('Upravit element', 'Upravit element ID %s');
$GLOBALS['TL_LANG']['tl_content']['editheader'] = array('Upravit nastavení článku', 'Upravit nastavení tohoto článku');
$GLOBALS['TL_LANG']['tl_content']['pasteafter'] = array('Vložit na začátek', 'Vložit za element ID %s');
$GLOBALS['TL_LANG']['tl_content']['pastenew'] = array('Vytvořit nový element na začátku', 'Vytvořit nový element po elementu ID %s');
$GLOBALS['TL_LANG']['tl_content']['toggle'] = array('Změnit zobrazení', 'Změní, zda bude element ID %s vidět nebo ne.');
$GLOBALS['TL_LANG']['tl_content']['editalias'] = array('Upravit zdrojový element', 'Upravit zdrojový element ID %s');
$GLOBALS['TL_LANG']['tl_content']['editarticle'] = array('Upravit článek', 'Upravit článek ID %s');

?>