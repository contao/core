<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_user']['username'] = array('Uživatelské jméno', 'Prosím zadejte jedinečné uživatelské jméno.');
$GLOBALS['TL_LANG']['tl_user']['name'] = array('Jméno', 'Prosím zadejte křestní jméno a příjmení.');
$GLOBALS['TL_LANG']['tl_user']['email'] = array('E-mailová adresa', 'Prosím zadejte správnou e-mailovou adresu.');
$GLOBALS['TL_LANG']['tl_user']['language'] = array('Jazyk backendu', 'Zde můžete zvolit jazyk backendu.');
$GLOBALS['TL_LANG']['tl_user']['backendTheme'] = array('Vzhled backendu', 'Zde můžete přepsat hlavní nastavení vzhledu backendu.');
$GLOBALS['TL_LANG']['tl_user']['uploader'] = array('Nahrávání souborů', 'Zde můžete zvolit, jakým způsobem budou nahrávány soubory na server.');
$GLOBALS['TL_LANG']['tl_user']['showHelp'] = array('Ukázat vysvětlivky', 'Ukázat kráké vysvětlivky pod každým polem.');
$GLOBALS['TL_LANG']['tl_user']['thumbnails'] = array('Ukázat náhledy obrázků', 'Ukázat náhledy obrázků v manažeru souborů.');
$GLOBALS['TL_LANG']['tl_user']['useRTE'] = array('Zapnout rozsáhlý textový editor', 'Použít rozsáhlý textový pro formátování textových elementů.');
$GLOBALS['TL_LANG']['tl_user']['useCE'] = array('Zapnout editor kódu', 'Použít editor kódu k úpravě kódovaného obsahu.');
$GLOBALS['TL_LANG']['tl_user']['pwChange'] = array('Vynutit změnu hesla', 'Zaškrtnutím této možnosti donutíte uživatele, aby změnili své heslo při dalším přihlášení.');
$GLOBALS['TL_LANG']['tl_user']['admin'] = array('Udělat uživatele administrátorem', 'Administrátoři mají neomezený přístup ke všem modulům a elementům!');
$GLOBALS['TL_LANG']['tl_user']['groups'] = array('Uživatelská skupina', 'Zde můžete zvolit skupinu, ke které bude nový uživatel patřit.');
$GLOBALS['TL_LANG']['tl_user']['inherit'] = array('Dědění práv', 'Zde můžet určit, jaká skupinová práva zdědí tento uživatel.');
$GLOBALS['TL_LANG']['tl_user']['group'] = array('Použít jen nastaveních skupiny', 'uživatel bude mít stejná práva jako skupina, ke níž náleží.');
$GLOBALS['TL_LANG']['tl_user']['extend'] = array('Rozšíření nastavení skupiny', 'přidat další práva, která nemá k dispozici skupina, ke které uživatel náleží.');
$GLOBALS['TL_LANG']['tl_user']['custom'] = array('Použít jen individuálních nastaveních', 'budou použitá jen individuální nastavení.');
$GLOBALS['TL_LANG']['tl_user']['modules'] = array('Moduly backendu', 'Zde můžete zajistit přístup k jednomu nebo více modulům backendu.');
$GLOBALS['TL_LANG']['tl_user']['themes'] = array('Vzhled modulů', 'Zde můžete zajistit přístup ke vzhledu modulů.');
$GLOBALS['TL_LANG']['tl_user']['pagemounts'] = array('Přístup ke stránkám', 'Zde můžete zajistit přístup k jedné nebo více stránkám (podstránky budou automaticky zahrnuty).');
$GLOBALS['TL_LANG']['tl_user']['alpty'] = array('Povolené typy stránek', 'Zde můžete zvolit typy stránke, které chcete povolit.');
$GLOBALS['TL_LANG']['tl_user']['filemounts'] = array('Přístup k adresářům souborů', 'Zde můžete zvolit jeden nebo více adresářů (podadresáře budou automaticky začleněny).');
$GLOBALS['TL_LANG']['tl_user']['forms'] = array('Povolené formuláře', 'Zde můžete určit přístup k jednomu nebo více formulářům.');
$GLOBALS['TL_LANG']['tl_user']['formp'] = array('Práva k ovládání s formuláři', 'Zde můžete určit práva pro zacházení s formuláři.');
$GLOBALS['TL_LANG']['tl_user']['disable'] = array('Deaktivovat', 'Dočasně deaktivovat účet.');
$GLOBALS['TL_LANG']['tl_user']['start'] = array('Aktivovat', 'Automaticky aktivovat v tento den.');
$GLOBALS['TL_LANG']['tl_user']['stop'] = array('Deaktivovat', 'Automaticky deaktivovat v tento den.');
$GLOBALS['TL_LANG']['tl_user']['session'] = array('Vyčistit data', 'Zvolte prosím data, která chcete vyčistit.');
$GLOBALS['TL_LANG']['tl_user']['name_legend'] = 'Jméno a mailová adresa';
$GLOBALS['TL_LANG']['tl_user']['backend_legend'] = 'Nastavení backendu';
$GLOBALS['TL_LANG']['tl_user']['theme_legend'] = 'Vzhled backendu';
$GLOBALS['TL_LANG']['tl_user']['password_legend'] = 'Nastavení hesla';
$GLOBALS['TL_LANG']['tl_user']['admin_legend'] = 'Administrátor';
$GLOBALS['TL_LANG']['tl_user']['groups_legend'] = 'Uživatelské skupiny';
$GLOBALS['TL_LANG']['tl_user']['modules_legend'] = 'Povolené moduly';
$GLOBALS['TL_LANG']['tl_user']['pagemounts_legend'] = 'Povolené stránky';
$GLOBALS['TL_LANG']['tl_user']['filemounts_legend'] = 'Povolené soubory';
$GLOBALS['TL_LANG']['tl_user']['forms_legend'] = 'Povolené formuláře';
$GLOBALS['TL_LANG']['tl_user']['account_legend'] = 'Nastavení účtu';
$GLOBALS['TL_LANG']['tl_user']['session_legend'] = 'Vyprázdnit cache';
$GLOBALS['TL_LANG']['tl_user']['sessionLabel'] = 'Data sezení';
$GLOBALS['TL_LANG']['tl_user']['htmlLabel'] = 'Cache obrázků';
$GLOBALS['TL_LANG']['tl_user']['tempLabel'] = 'Dočasný adresář';
$GLOBALS['TL_LANG']['tl_user']['sessionPurged'] = 'Data sezení byla vyčištěna';
$GLOBALS['TL_LANG']['tl_user']['htmlPurged'] = 'Cache obrázků byl vyprázdněn';
$GLOBALS['TL_LANG']['tl_user']['tempPurged'] = 'Dočasný adresář byl vyprázdněn';
$GLOBALS['TL_LANG']['tl_user']['FileUpload'] = 'Výchozí způsob nahrávání souborů';
$GLOBALS['TL_LANG']['tl_user']['new'] = array('Nový uživatel', 'Vytvořit nového uživatele');
$GLOBALS['TL_LANG']['tl_user']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k uživateli ID %s');
$GLOBALS['TL_LANG']['tl_user']['edit'] = array('Upravit uživatele', 'Upravit uživatele ID %s');
$GLOBALS['TL_LANG']['tl_user']['copy'] = array('Duplikovat uživatele', 'Duplikovat uživatel ID %s');
$GLOBALS['TL_LANG']['tl_user']['delete'] = array('Smazat uživatele', 'Smazat uživatel ID %s');
$GLOBALS['TL_LANG']['tl_user']['toggle'] = array('Aktivovat / deaktivovat', 'Aktivovat / deaktivovat uživatele');
$GLOBALS['TL_LANG']['tl_user']['su'] = array('Změnit uživatele', 'Změnit za uživatele ID %s');

?>