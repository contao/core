<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['XPL']['insertTags'][0] = array('Obsáhlý textový editor', 'Více informací o TinyMCE najdete na <a href="http://tinymce.moxiecode.com" title="TinyMCE by moxiecode" onclick="window.open(this.href); return false;">http://tinymce.moxiecode.com</a>.');
$GLOBALS['TL_LANG']['XPL']['insertTags'][1] = array('Vložit tagy', 'Více informací najdete na <a href="http://www.contao.org/insert-tags.html" title="Contao online documentation" onclick="window.open(this.href); return false;">http://www.contao.org/insert-tags.html</a>.');
$GLOBALS['TL_LANG']['XPL']['insertTags'][2] = array('Editor kódu', 'Pro další informace k EditArea navštivte prosím <a href="http://www.cdolivet.com/index.php?page=editArea" title="EditArea by Christophe Dolivet" onclick="window.open(this.href); return false;">http://www.cdolivet.com/index.php?page=editArea</a>.');
$GLOBALS['TL_LANG']['XPL']['dateFormat'][0] = array('colspan', 'Contao podporuje všechny formáty datumu a času pomocí funkce PHP date(). Aby se zobrazily správné formáty, jsou povelené jen tyto znaky: j, d, m, n, y, Y, g, G, h, H, i, s.<br /><br /><strong>Odlišné formáty můžou být uvedené v nastavení jednotlivých stránek.</strong><br /><br /><em>Zde jsou některé příklady platných formátů</em>:');
$GLOBALS['TL_LANG']['XPL']['dateFormat'][1] = array('Y-m-d', 'RRRR-MM-DD, mezinárodní ISO 8601 př.: 2005-01-28');
$GLOBALS['TL_LANG']['XPL']['dateFormat'][2] = array('m/d/Y', 'MM/DD/RRRR, anglický formát př.: 01/28/2005');
$GLOBALS['TL_LANG']['XPL']['dateFormat'][3] = array('d.m.Y', 'DD.MM.RRRR, německý formát př.: 28.01.2005');
$GLOBALS['TL_LANG']['XPL']['dateFormat'][4] = array('y-n-j', 'RR-M-D, bez prvních nul př.: 05-1-25');
$GLOBALS['TL_LANG']['XPL']['dateFormat'][5] = array('Ymd', 'YYYYMMDD, časová značka př.: 20050128');
$GLOBALS['TL_LANG']['XPL']['dateFormat'][6] = array('H:i:s', '24 hodin, minut a sekund, např. 20:36:59');
$GLOBALS['TL_LANG']['XPL']['dateFormat'][7] = array('g:i', '12 hodin bez nul a minut na začátku, např. 8:36');
$GLOBALS['TL_LANG']['XPL']['highlighter'][0] = array('Obsáhlý textový editor', 'další informace, jak nastavit "syntaxe highlighter", najdete na <a href="http://alexgorbatchev.com/wiki/SyntaxHighlighter:Configuration#SyntaxHighlighter.defaults" title="SyntaxHighlighter by Alex Gorbatchev" onclick="window.open(this.href); return false;">http://alexgorbatchev.com</a>.');

?>