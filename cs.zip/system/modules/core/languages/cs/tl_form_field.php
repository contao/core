<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['FFL']['headline'] = array('Nadpis', 'vlastní pole pro uvedení nadpisu jisté části.');
$GLOBALS['TL_LANG']['FFL']['explanation'] = array('Vysvětlivka', 'vlastní pole pro uvedení vysvětlivky.');
$GLOBALS['TL_LANG']['FFL']['html'] = array('Kód HTML', 'vlastní pole pro uvedení kód HTML.');
$GLOBALS['TL_LANG']['FFL']['fieldset'] = array('Skupina polí', 'blok, v němž se nachází několik polí formuláře a u kterého je možné uvést legendu.');
$GLOBALS['TL_LANG']['FFL']['text'] = array('Textové pole', 'pro uvedení krátkého či delšího textu.');
$GLOBALS['TL_LANG']['FFL']['password'] = array('Pole pro heslo', 'jednořádkové pole pro vložení hesla. Contao k tomu automaticky přidá druhé pole, v němž se musí ještě jednou uvést před tím zadané heslo.');
$GLOBALS['TL_LANG']['FFL']['textarea'] = array('Textová oblast', 'víceřádkové pole, do něhož se může zadat delší text (např. sdělení).');
$GLOBALS['TL_LANG']['FFL']['select'] = array('Rozvírací menu', 'jedno- nebo víceřádkové rozevírací menu.');
$GLOBALS['TL_LANG']['FFL']['radio'] = array('Výběrové tlačítko', 'seznam výběrových tlačítek, z nichž jen jedno může být označeno.');
$GLOBALS['TL_LANG']['FFL']['checkbox'] = array('Zaškrtávací políčko', 'seznam různých možností');
$GLOBALS['TL_LANG']['FFL']['upload'] = array('Přenos souborů', 'jednořádkové pole na nahrání a přenos souborů na server přes formulář.');
$GLOBALS['TL_LANG']['FFL']['hidden'] = array('Skryté pole', 'jednořádkové pole, které je skryté.');
$GLOBALS['TL_LANG']['FFL']['captcha'] = array('Bezpečnostní otázka', 'Jednoduchá výpočetní otázka, kterou musí před odesláním vypočítat osoba vyplňující formulář.');
$GLOBALS['TL_LANG']['FFL']['submit'] = array('Tlačítko "odeslat"', 'tlačítko pro odeslání formuláře.');
$GLOBALS['TL_LANG']['tl_form_field']['type'] = array('Typ polí', 'Zvolte prosím jeden z druhů polí.');
$GLOBALS['TL_LANG']['tl_form_field']['name'] = array('Název pole', 'Název pole je jednoznačným pojmenováním k identifikaci pole.');
$GLOBALS['TL_LANG']['tl_form_field']['label'] = array('Popisek pole', 'Popisek pole se zobrazí na webové stránce vedle pole.');
$GLOBALS['TL_LANG']['tl_form_field']['text'] = array('Text', 'Můžete použít znaků HTML pro naformátování textu.');
$GLOBALS['TL_LANG']['tl_form_field']['html'] = array('HTML', 'Povolené znaky HTML můžete nadefinovat v nastaveních backend systému.');
$GLOBALS['TL_LANG']['tl_form_field']['options'] = array('Možnosti', 'Máte-li vypnutou javu, uložte prosím veškeré změny před úpravou této položky.');
$GLOBALS['TL_LANG']['tl_form_field']['mandatory'] = array('Povinné pole', 'Formulář nebude odeslán, pokud zůstane toto pole nevyplněné.');
$GLOBALS['TL_LANG']['tl_form_field']['rgxp'] = array('Kontrola údajů', 'Zkontrolovat správnost zadaných údajů před jejich odesláním');
$GLOBALS['TL_LANG']['tl_form_field']['digit'] = array('Číselné znaky', 'povolené číselné znaky: mínus (-), tečka (.) a mezera ( ).');
$GLOBALS['TL_LANG']['tl_form_field']['alpha'] = array('Abecední znaky', 'povolené abecední znaky, mínus (-), tečka (.) a mezera ( ).');
$GLOBALS['TL_LANG']['tl_form_field']['alnum'] = array('Abecední a číselné znaky', 'povolené abecední a číselné znaky - mínus (-), tečka (.), podtržítko (_) a mezera ( ).');
$GLOBALS['TL_LANG']['tl_form_field']['extnd'] = array('Rozšířené abecední a číselné znaky', 'povolí cokoli kromě speciálních znaků, které jsou běžně');
$GLOBALS['TL_LANG']['tl_form_field']['date'] = array('Datum', 'zkontroluje, zda zadané údaje souhlasí s nastavením data v systému.');
$GLOBALS['TL_LANG']['tl_form_field']['time'] = array('Čas', 'zkontroluje, zda zadané údaje souhlasí s nastavením času v systému.');
$GLOBALS['TL_LANG']['tl_form_field']['datim'] = array('Datum a čas', 'zkontroluje, zda zadané údaje souhlasí s nastavením data a času v systému.');
$GLOBALS['TL_LANG']['tl_form_field']['phone'] = array('Telefonní číslo', 'povolené abecední a číselné znaky: plus (+), mínus (-), lomítko (/), závorky () a mezera ( ).');
$GLOBALS['TL_LANG']['tl_form_field']['email'] = array('Mailová adresa', 'zkontroluje, zda zadaná mailová adresa je ve správném tvaru.');
$GLOBALS['TL_LANG']['tl_form_field']['url'] = array('Formát internetové adresy', 'zkontroluje, zda zadaný údaj odpovídá správnému formátu internetové adresy.');
$GLOBALS['TL_LANG']['tl_form_field']['placeholder'] = array('Zástupný znak', 'Zobrazit tento text, dokud bude pole prázdné (vyžaduje HTML5)');
$GLOBALS['TL_LANG']['tl_form_field']['maxlength'] = array('Maximální délka údaje', 'Zde můžete určit maximální počet znaků (text) nebo velikost (nahrávání souborů).');
$GLOBALS['TL_LANG']['tl_form_field']['size'] = array('Řádky a sloupce', 'Počet řádků a sloupců textové oblasti.');
$GLOBALS['TL_LANG']['tl_form_field']['multiple'] = array('Vícenásobný výběr', 'Umožní návštěvníkům vybrat víc než jednu možnost.');
$GLOBALS['TL_LANG']['tl_form_field']['mSize'] = array('Velikost seznamu', 'Zde můžete zadat velikost výběrového seznamu.');
$GLOBALS['TL_LANG']['tl_form_field']['extensions'] = array('Povolené druhy souborů', 'seznam povolených souborů oddělených čárkou.');
$GLOBALS['TL_LANG']['tl_form_field']['storeFile'] = array('Uložit odeslané soubory', 'Přesunout nahrané soubory do adresáře na serveru.');
$GLOBALS['TL_LANG']['tl_form_field']['uploadFolder'] = array('Cílový adresář', 'Zvolte prosím cílový adresář na serveru.');
$GLOBALS['TL_LANG']['tl_form_field']['useHomeDir'] = array('Použít domovský adresář', 'Uložit nahrávané soubory do domácího adresáře, pokud je přihlášený alespoň jeden z uživatelů.');
$GLOBALS['TL_LANG']['tl_form_field']['doNotOverwrite'] = array('Očíslovat existující soubory', 'Přidá číslo k souborům, které se jmenují stejně jako ty, které se už nachází v cílovém adresáři.');
$GLOBALS['TL_LANG']['tl_form_field']['fsType'] = array('Mudus operace', 'Zvolte prosím modus operace pro element Skupina polí.');
$GLOBALS['TL_LANG']['tl_form_field']['fsStart'] = array('Začátek obálky', 'Označuje začátek skupiny polí a může obsahovat legendu.');
$GLOBALS['TL_LANG']['tl_form_field']['fsStop'] = array('Konec obálky', 'Označuje konec skupiny polí.');
$GLOBALS['TL_LANG']['tl_form_field']['value'] = array('Výchozí hodnota', 'Zde můžete zadat výchozí hodnotu pro dané pole, která se v něm objeví před samotným vyplněním pole.');
$GLOBALS['TL_LANG']['tl_form_field']['class'] = array('Třída CSS', 'Sem můžete zadat více tříd kaskádovitých stylů CSS (class)');
$GLOBALS['TL_LANG']['tl_form_field']['accesskey'] = array('Klávesová zkratka', 'Pole formuláře mohou být vybrána pomocí příslušných klávesových zkratek, když stisknete [ALT]+ respektive [STRG]+danou klávesu.');
$GLOBALS['TL_LANG']['tl_form_field']['tabindex'] = array('Index tabulátoru', 'Uspořádání formulářového pole podle tabulátoru.');
$GLOBALS['TL_LANG']['tl_form_field']['fSize'] = array('Velikost pole', 'Sem můžete uvést velikost pole pro stahování (hodnoty pro velikost)');
$GLOBALS['TL_LANG']['tl_form_field']['addSubmit'] = array('Přidat tlačítko k odeslání', 'Přidat vedle pole tlačítko k odeslání, aby se vytvořil jednořádkový formulář.');
$GLOBALS['TL_LANG']['tl_form_field']['slabel'] = array('Označení tlačítka k odeslání', 'Zadejte prosím označení tlačítka.');
$GLOBALS['TL_LANG']['tl_form_field']['imageSubmit'] = array('Vytvořit tlačítko z obrázku', 'Použít obrázku namísto běžného tlačítka.');
$GLOBALS['TL_LANG']['tl_form_field']['singleSRC'] = array('Zdroj dat', 'Vyberte prosím jeden obrázek z adresáře souborů.');
$GLOBALS['TL_LANG']['tl_form_field']['type_legend'] = 'Nízev a typ souboru';
$GLOBALS['TL_LANG']['tl_form_field']['text_legend'] = 'Text/HTML';
$GLOBALS['TL_LANG']['tl_form_field']['fconfig_legend'] = 'Konfigurace pole';
$GLOBALS['TL_LANG']['tl_form_field']['options_legend'] = 'Možnosti';
$GLOBALS['TL_LANG']['tl_form_field']['store_legend'] = 'Uložit soubor';
$GLOBALS['TL_LANG']['tl_form_field']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_form_field']['submit_legend'] = 'Tlačítko pro odeslání';
$GLOBALS['TL_LANG']['tl_form_field']['image_legend'] = 'Obrázkové tlačítko';
$GLOBALS['TL_LANG']['tl_form_field']['new'] = array('Vytvořit nové pole', 'Vytvořit nové pole');
$GLOBALS['TL_LANG']['tl_form_field']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k poli ID %s');
$GLOBALS['TL_LANG']['tl_form_field']['edit'] = array('Upravit pole', 'Upravit pole ID %s');
$GLOBALS['TL_LANG']['tl_form_field']['cut'] = array('Přesunout pole', 'Přesunout pole ID %s');
$GLOBALS['TL_LANG']['tl_form_field']['copy'] = array('Duplikovat pole', 'Duplikovat pole ID %s');
$GLOBALS['TL_LANG']['tl_form_field']['delete'] = array('Smazat pole', 'Smazat pole ID %s');
$GLOBALS['TL_LANG']['tl_form_field']['editheader'] = array('Upravit formulář', 'Nastavit formulář');
$GLOBALS['TL_LANG']['tl_form_field']['pasteafter'] = array('Vložit nahoře', 'Vložit za pole ID %s');
$GLOBALS['TL_LANG']['tl_form_field']['pastenew'] = array('Vytvořit nové nahoře', 'Vytvořit nové pole za polem ID %s');
$GLOBALS['TL_LANG']['tl_form_field']['toggle'] = array('Změnit zobrazení', 'Změnit zobrazení pole ID %s');

?>