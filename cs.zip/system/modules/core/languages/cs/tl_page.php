<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_page']['title'] = array('Jméno stránky', 'Jméno stránky je zobrazeno v navigaci webu');
$GLOBALS['TL_LANG']['tl_page']['alias'] = array('Alias stránka', 'Alias stránky slouží jako náhrada ID stránky a může být taky zádán v adresním poli prohlížeče.');
$GLOBALS['TL_LANG']['tl_page']['type'] = array('Typ stránky', 'Zvolte prosím typ stránky');
$GLOBALS['TL_LANG']['tl_page']['pageTitle'] = array('Název stránky', 'Zadejte prosím název stránky');
$GLOBALS['TL_LANG']['tl_page']['language'] = array('Jazyk', 'Zadejte prosím zkratku jazyka stránky podle ISO-639-1 (např. "cs" pro češtinu nebo "en" pro angličtinu).');
$GLOBALS['TL_LANG']['tl_page']['robots'] = array('Tag pro hledací roboty', 'Zde můžete nastavit, jak mají tuto stránku vnímat vyhledávací roboti.');
$GLOBALS['TL_LANG']['tl_page']['description'] = array('Popis stránky', 'Sem můžete uvést krátký popis stránky, který poslouží při hodnocení jejího obsahu při vyhledávání přes Yahoo nebo Google. Vyhledávací roboti dokáží většinou přečíst mezi 150 a 300 znaky.');
$GLOBALS['TL_LANG']['tl_page']['redirect'] = array('Typ přesměrování', 'Zvolte prosím typ přesměrování');
$GLOBALS['TL_LANG']['tl_page']['jumpTo'] = array('Přesměrovat na', 'Zvolte prosím stránku, na níž budou návštěvníci přesměrováni. Ponecháte-li pole prázdné, budou přesměrováni na úvodní stránku.');
$GLOBALS['TL_LANG']['tl_page']['fallback'] = array('Přesměrování na jazykovou verzi', 'Ukázat tuto stránku, pokud je operační systém návštěvníka v dané řeči či v nějaké jiné, v níž není ani jedna jazykových verzí Vaší webové stránky.');
$GLOBALS['TL_LANG']['tl_page']['dns'] = array('Jméno domény', 'Zde můžete omezit přístup na webovou stránku na určité domény.');
$GLOBALS['TL_LANG']['tl_page']['adminEmail'] = array('E-mailová adresa administrátora webu', 'Automaticky vytvořené zprávy jako objednání Zpravodaje budou přeposílány na tuto mailovou adresu.');
$GLOBALS['TL_LANG']['tl_page']['dateFormat'] = array('Formát data', 'Prosím zadejte formát data použitý PHP funkcí date().');
$GLOBALS['TL_LANG']['tl_page']['timeFormat'] = array('Formát času', 'Prosím zadejte formát času použitý PHP funkcí date().');
$GLOBALS['TL_LANG']['tl_page']['datimFormat'] = array('Formát data a času', 'Prosím zadejte formát data a času použitý PHP funkcí date().');
$GLOBALS['TL_LANG']['tl_page']['createSitemap'] = array('Vytvořit XML mapu stránek', 'Vytvořit Google XML mapu stránek v kořenovém adresáři');
$GLOBALS['TL_LANG']['tl_page']['sitemapName'] = array('Název souboru', 'Zadejte jméno XML souboru');
$GLOBALS['TL_LANG']['tl_page']['useSSL'] = array('Použít HTTPS v mapě stránek', 'Vytvoří mapu stránek s internetovými odkazy začínajícími na <em>https://</em>');
$GLOBALS['TL_LANG']['tl_page']['autoforward'] = array('Přesměrovat na jinou stránku', 'Přesměrovat návštěvníky na jinou stránku (např. na přihlašovací stránku).');
$GLOBALS['TL_LANG']['tl_page']['protected'] = array('Chránit stránku', 'Umožnit přístup na stránku jen členům skupin.');
$GLOBALS['TL_LANG']['tl_page']['groups'] = array('Povolené členské skupiny', 'Tyta skupiny budou mít povolený přístup na výše uvedenou stránku.');
$GLOBALS['TL_LANG']['tl_page']['includeLayout'] = array('Přiřadit vzhled', 'Přiřadit ke stránce určitý vzhled a jeho náležitosti.');
$GLOBALS['TL_LANG']['tl_page']['layout'] = array('Vzhled stránky', 'Vzhled stránky můžete nastavit v části "rozvržení stránky".');
$GLOBALS['TL_LANG']['tl_page']['includeCache'] = array('Nastavit dobu cache', 'Nastaví, po jakou dobu se budou ukládat navštívené stránky návštěvníkům na jejich počítači.');
$GLOBALS['TL_LANG']['tl_page']['cache'] = array('Doba ukládání do cache', 'Po této době bude smazána uložená verze dané stránky z cache na počítači.');
$GLOBALS['TL_LANG']['tl_page']['includeChmod'] = array('Přidělit přístupová práva', 'Nastaví, co budou smět s touto stránkou dělat uživatelé Contao.');
$GLOBALS['TL_LANG']['tl_page']['cuser'] = array('Vlastník', 'Vyberte vlastníka současné stránky');
$GLOBALS['TL_LANG']['tl_page']['cgroup'] = array('Skupina', 'Vyberte skupinu jako vlastníka současné stránky');
$GLOBALS['TL_LANG']['tl_page']['chmod'] = array('Přístupová práva', 'Určete prosím práva pro tuto stránku a její součásti.');
$GLOBALS['TL_LANG']['tl_page']['noSearch'] = array('Nevyhledávat', 'Neindexovat tuto stránku');
$GLOBALS['TL_LANG']['tl_page']['cssClass'] = array('Kaskádovité styly', 'Tyto styly budou zahrnuty do navigace a do tagu body.');
$GLOBALS['TL_LANG']['tl_page']['sitemap'] = array('Ukázat ve struktuře webové stránky', 'Zde můžete určit, zda se stránka objeví ve výpisu struktury Vaší webové stránky.');
$GLOBALS['TL_LANG']['tl_page']['hide'] = array('Skrýt stránku v navigaci', 'Skrýt stránku v navigačním menu');
$GLOBALS['TL_LANG']['tl_page']['guests'] = array('Ukázat pouze hostům', 'Skrýt stránku z navigačního menu pokud je uživatel přihlášen');
$GLOBALS['TL_LANG']['tl_page']['tabindex'] = array('Index tabulátoru', 'Procházení navigace pomocí tabulátoru.');
$GLOBALS['TL_LANG']['tl_page']['accesskey'] = array('Klávesová zkratka', 'Součásti navigace mohou být vybrané zmáčknutím klávesy [ALT] nebo [CTRL] a příslušného znaku.');
$GLOBALS['TL_LANG']['tl_page']['published'] = array('Publikovat', 'Zveřejní stránku na webové stránce.');
$GLOBALS['TL_LANG']['tl_page']['start'] = array('Zobrazit od', 'Nezobrazovat stránku před tímto datem.');
$GLOBALS['TL_LANG']['tl_page']['stop'] = array('Zobrazit do', 'Nezobrazovat stránku po tomto datu.');
$GLOBALS['TL_LANG']['tl_page']['title_legend'] = 'Název a typ';
$GLOBALS['TL_LANG']['tl_page']['meta_legend'] = 'Meta';
$GLOBALS['TL_LANG']['tl_page']['system_legend'] = 'Nastavení systému';
$GLOBALS['TL_LANG']['tl_page']['redirect_legend'] = 'Přesměrování';
$GLOBALS['TL_LANG']['tl_page']['dns_legend'] = 'Nastavení DNS';
$GLOBALS['TL_LANG']['tl_page']['sitemap_legend'] = 'Stuktura webu XML';
$GLOBALS['TL_LANG']['tl_page']['forward_legend'] = 'Automatické přesměrování';
$GLOBALS['TL_LANG']['tl_page']['protected_legend'] = 'Chráněný přístup';
$GLOBALS['TL_LANG']['tl_page']['layout_legend'] = 'Nastavení vzhledu';
$GLOBALS['TL_LANG']['tl_page']['cache_legend'] = 'Nastavení cache';
$GLOBALS['TL_LANG']['tl_page']['chmod_legend'] = 'Přístupová práva';
$GLOBALS['TL_LANG']['tl_page']['search_legend'] = 'Nastavení vyhledávání';
$GLOBALS['TL_LANG']['tl_page']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_page']['tabnav_legend'] = 'Ovládání pomocí klávesových zkratek';
$GLOBALS['TL_LANG']['tl_page']['publish_legend'] = 'Nastavení publikování';
$GLOBALS['TL_LANG']['tl_page']['permanent'] = 'trvalý';
$GLOBALS['TL_LANG']['tl_page']['temporary'] = 'dočasný';
$GLOBALS['TL_LANG']['tl_page']['map_default'] = 'Výchozí';
$GLOBALS['TL_LANG']['tl_page']['map_always'] = 'Vždy ukázat';
$GLOBALS['TL_LANG']['tl_page']['map_never'] = 'Nikdy neukazovat';
$GLOBALS['TL_LANG']['tl_page']['new'] = array('Nová stránka', 'Vytvořit novou stránku');
$GLOBALS['TL_LANG']['tl_page']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti ke stránce ID %s');
$GLOBALS['TL_LANG']['tl_page']['edit'] = array('Upravit stránku', 'Upravit stránku ID %s');
$GLOBALS['TL_LANG']['tl_page']['cut'] = array('Přesunout stránku', 'Přesunout stránku ID %s');
$GLOBALS['TL_LANG']['tl_page']['copy'] = array('Duplikovat stránku', 'Duplikovat stránku ID %s');
$GLOBALS['TL_LANG']['tl_page']['copyChilds'] = array('Duplikovat stránku s podstránkamy', 'Duplikovat stránku ID %s s podstránkamy');
$GLOBALS['TL_LANG']['tl_page']['delete'] = array('Smazat stránku', 'Smazat stránku ID %s');
$GLOBALS['TL_LANG']['tl_page']['toggle'] = array('Publikovat / nepublikovat', 'Publikovat / nepublikovat stránku ID %s');
$GLOBALS['TL_LANG']['tl_page']['pasteafter'] = array('Vložit za', 'Vložit za stránku ID %s');
$GLOBALS['TL_LANG']['tl_page']['pasteinto'] = array('Vložit do', 'Vložit do stránky ID %s');
$GLOBALS['TL_LANG']['tl_page']['articles'] = array('Upravit článek', 'Upravit článek stránky ID %s');
$GLOBALS['TL_LANG']['CACHE'][0] = '0 (bez cache)';
$GLOBALS['TL_LANG']['CACHE'][5] = '5 sekund';
$GLOBALS['TL_LANG']['CACHE'][15] = '15 sekund';
$GLOBALS['TL_LANG']['CACHE'][30] = '30 sekund';
$GLOBALS['TL_LANG']['CACHE'][60] = '1 minuta';
$GLOBALS['TL_LANG']['CACHE'][300] = '5 minut';
$GLOBALS['TL_LANG']['CACHE'][900] = '15 minut';
$GLOBALS['TL_LANG']['CACHE'][1800] = '30 minut';
$GLOBALS['TL_LANG']['CACHE'][3600] = '1 hodina';
$GLOBALS['TL_LANG']['CACHE'][10800] = '3 hodiny';
$GLOBALS['TL_LANG']['CACHE'][21600] = '6 hodin';
$GLOBALS['TL_LANG']['CACHE'][43200] = '12 hodin';
$GLOBALS['TL_LANG']['CACHE'][86400] = '1 den';
$GLOBALS['TL_LANG']['CACHE'][259200] = '3 dny';
$GLOBALS['TL_LANG']['CACHE'][604800] = '7 dní';
$GLOBALS['TL_LANG']['CACHE'][2592000] = '30 dní';

?>