<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_module']['name'] = array('Jméno modulu', 'Zadejte unikátní jméno modulu');
$GLOBALS['TL_LANG']['tl_module']['headline'] = array('Hlavička', 'Pokud zadáte hlavičku, bude zobrazena nahoře modulu');
$GLOBALS['TL_LANG']['tl_module']['type'] = array('Typ modulu', 'Zvolte typ tohoto modulu');
$GLOBALS['TL_LANG']['tl_module']['levelOffset'] = array('Startovací úroveň', 'Zadejte hodnotu větší než 0 pro zobrazení položek podmenu.');
$GLOBALS['TL_LANG']['tl_module']['showLevel'] = array('Zastavovací úroveň', 'Zadejte hodnotu větší než 0, abyste omezili podúrovně menu.');
$GLOBALS['TL_LANG']['tl_module']['hardLimit'] = array('Tvrdý limit', 'Nikdy nezobrazovat součásti menu mimo úroveň stopu.');
$GLOBALS['TL_LANG']['tl_module']['showProtected'] = array('Ukázat chráněné elementy', 'Zobrazit elementy, které mohou jinak vidět jen autorizovaní uživatelé.');
$GLOBALS['TL_LANG']['tl_module']['defineRoot'] = array('Určit referenční stránku', 'Přiřadit vlastní zdroj nebo cílovou stránku modulu.');
$GLOBALS['TL_LANG']['tl_module']['rootPage'] = array('Referenční stránka', 'Zvolte prosím stránku ze struktury stránek.');
$GLOBALS['TL_LANG']['tl_module']['navigationTpl'] = array('Předloha navigace', 'Zde můžete vybrat předlohu navigace');
$GLOBALS['TL_LANG']['tl_module']['pages'] = array('Stránky', 'Vyberte prosím jednu nebo více stránek ze struktury stránek.');
$GLOBALS['TL_LANG']['tl_module']['showHidden'] = array('Ukázat skryté elementy', 'Ukázat elementy v navigaci, které jsou jinak skryté.');
$GLOBALS['TL_LANG']['tl_module']['customLabel'] = array('Vlastní údaj', 'Zde můžete zadat vlastní údaj pro rozbalovací menu.');
$GLOBALS['TL_LANG']['tl_module']['autologin'] = array('Povolit automatické přihlášení', 'Povolí členům automatické přihlášení do frontendu.');
$GLOBALS['TL_LANG']['tl_module']['jumpTo'] = array('Přesměrování na stránku', 'Zvolte prosím stránku, na kterou bude přesměrovaný návštěvník poté, co kliknul na tlačítko odeslat.');
$GLOBALS['TL_LANG']['tl_module']['redirectBack'] = array('Přesměrování na poslední navštívenou stránku', 'Přesměrovat uživatele na poslední navštívenou stránku místo na stránku určenou k přesměrování.');
$GLOBALS['TL_LANG']['tl_module']['cols'] = array('Počet sloupců', 'Zvolte prosím počet sloupců pro zobrazení formuláře v backendu.');
$GLOBALS['TL_LANG']['tl_module']['1cl'] = array('Jeden sloupec', 'zobrazit popisek nad polem.');
$GLOBALS['TL_LANG']['tl_module']['2cl'] = array('Dva sloupce', 'zobrazit popisek vlevo vedle pole.');
$GLOBALS['TL_LANG']['tl_module']['editable'] = array('Upravitelná pole', 'Zobrazit tato pole ve formuláři ve frontendu.');
$GLOBALS['TL_LANG']['tl_module']['memberTpl'] = array('Předloha formuláře', 'Zde můžete zvolit předlohu formuláře.');
$GLOBALS['TL_LANG']['tl_module']['tableless'] = array('Bez tabulky', 'Formulář bude naformátovaný bez tabulky.');
$GLOBALS['TL_LANG']['tl_module']['form'] = array('Formulář', 'Zvolte prosím formulář.');
$GLOBALS['TL_LANG']['tl_module']['queryType'] = array('Výchozí typ dotazu', 'Zvolte prosím výchozí typ dotazu.');
$GLOBALS['TL_LANG']['tl_module']['and'] = array('Vyhledej všechna slova', 'najde jen ty stránky, které obsahují dané slovo.');
$GLOBALS['TL_LANG']['tl_module']['or'] = array('Vyhledej jakýkoliv slovo', 'najde všechny stránky, které obsahují dané slovo.');
$GLOBALS['TL_LANG']['tl_module']['fuzzy'] = array('Nepřesné vyhledávání', 'Najde např. "Contao" při zadání slova "con".');
$GLOBALS['TL_LANG']['tl_module']['simple'] = array('Jednoduchý formulář', 'obsahuje jen jedno pole.');
$GLOBALS['TL_LANG']['tl_module']['advanced'] = array('Pokročilejší formulář', 'obsahuje jedno pole a jedno výběrové tlačítko pro volbu typu dotazu.');
$GLOBALS['TL_LANG']['tl_module']['contextLength'] = array('Rozpětí vyhledaného záznamů', 'Počet znaků, které lze použít nalevo a napravo hledaného výrazu jako kontextu.');
$GLOBALS['TL_LANG']['tl_module']['totalLength'] = array('Maximální délka nalezených záznamů', 'Zde můžete zadat maximální délku pro každý výsledek vyhledávání.');
$GLOBALS['TL_LANG']['tl_module']['perPage'] = array('Počet záznamů na stránku', 'Počet záznamů na stránku. Zadejte 0, pokud chcete vypnout zalamování stránky.');
$GLOBALS['TL_LANG']['tl_module']['searchType'] = array('Vzhled vyhledávacího formuláře', 'Zde můžete zvolit vzhled vyhledávacího formuláře.');
$GLOBALS['TL_LANG']['tl_module']['searchTpl'] = array('Předloha pro výsledky vyhledávání', 'Zde můžete vybrat předlohu pro výsledky vyhledávání.');
$GLOBALS['TL_LANG']['tl_module']['inColumn'] = array('Sloupce', 'Vyberte prosím sloupec, jehož články chcete zobrazit v seznamu.');
$GLOBALS['TL_LANG']['tl_module']['skipFirst'] = array('Přeskočit elementy', 'Zde můžete učit, kolik elementů se má přeskočit.');
$GLOBALS['TL_LANG']['tl_module']['loadFirst'] = array('Nahrát první element', 'Automaticky přesměrovat k prvnímu elementu, pokud není již vybraný nějaký jiný.');
$GLOBALS['TL_LANG']['tl_module']['size'] = array('Šírka a výška', 'Zadejte prosím šířku a výšku v pixelech.');
$GLOBALS['TL_LANG']['tl_module']['transparent'] = array('Průhlednost filmu', 'nastavit míru průhlednosti flashového filmu (wmode = průhledný)');
$GLOBALS['TL_LANG']['tl_module']['flashvars'] = array('FlashVars', 'Předat flashi proměnlivé (<em>var1=value1&var2=value2</em>).');
$GLOBALS['TL_LANG']['tl_module']['version'] = array('Verze Flashového přehrávače', 'Zadejte prosím požadovanou verzi Flash player (např. 6.0.12).');
$GLOBALS['TL_LANG']['tl_module']['altContent'] = array('Alternativní obsah', 'Alternativní obsah se zobrazí místo flasha, pokud je flashový obsah zakázaný nebo pokud není nainstalované potřebné rozšíření.');
$GLOBALS['TL_LANG']['tl_module']['source'] = array('Zdroj', 'Použít soubor uložený na serveru nebo externí internetovou adresu.');
$GLOBALS['TL_LANG']['tl_module']['singleSRC'] = array('Zdrojový soubor', 'Vyberte soubor z adresáře');
$GLOBALS['TL_LANG']['tl_module']['url'] = array('Internetová adresa', 'Zadejte prosím internetovou adresu (http://...) daného flashového videa.');
$GLOBALS['TL_LANG']['tl_module']['interactive'] = array('Přidat interativní funkcionalitu', 'Přidat snímku interaktivní funkcionalitu, kterou lze využít v prohlížeči (vyžaduje JavaScript).');
$GLOBALS['TL_LANG']['tl_module']['flashID'] = array('Flashové video ID', 'Zadejte prosím jednoznačné ID flashového videa.');
$GLOBALS['TL_LANG']['tl_module']['flashJS'] = array('JavaScript _DoFSCommand(command, args) {', 'Zadejte prosím kód JavaScriptu.');
$GLOBALS['TL_LANG']['tl_module']['fullsize'] = array('Zobrazit v plné velikost v lightboxu/nové okno', 'Zobrazit obrázek v maximální velikosti v rozevíracím rámu lightboxu - stane se tak po kliknutí na obrázek.');
$GLOBALS['TL_LANG']['tl_module']['imgSize'] = array('Šířka a výška obrázku', 'Zde můžete zadat rozměry a metodu zobrazení obrázku.');
$GLOBALS['TL_LANG']['tl_module']['useCaption'] = array('Zobrazit popisek', 'Zobrazit název nebo popisek obrázku pod ním.');
$GLOBALS['TL_LANG']['tl_module']['multiSRC'] = array('Zdrojový soubor', 'Vyberte jeden nebo více souborů z adresáře');
$GLOBALS['TL_LANG']['tl_module']['html'] = array('Kód HTML', 'Seznam povolených znaků HTML můžete upravit v nastaveních systému.');
$GLOBALS['TL_LANG']['tl_module']['protected'] = array('Chránit modul', 'Ukázat modul jen některým členům skupiny.');
$GLOBALS['TL_LANG']['tl_module']['groups'] = array('Povolené členské skupiny', 'Zvolená skupina bude smět vidět daný modul.');
$GLOBALS['TL_LANG']['tl_module']['guests'] = array('Ukázat jen hostům', 'Skrýt modul, pokud je přihlášený alespoň jeden z členů.');
$GLOBALS['TL_LANG']['tl_module']['cssID'] = array('Kaskádovitý styl ID/class', 'Zde můžete zadat ID nebo jednu nebo více tříd (class) kaskádovitých stylů.');
$GLOBALS['TL_LANG']['tl_module']['space'] = array('Odsazení před a po', 'Zde můžete zadat odsazení před a po modulu v pixelích. Měli byste se ale vyvarovat jakýchkoli stylů nenadefinovaných centrálně v sekci "Styly".');
$GLOBALS['TL_LANG']['tl_module']['title_legend'] = 'Název a typ';
$GLOBALS['TL_LANG']['tl_module']['nav_legend'] = 'Nastavení navigace';
$GLOBALS['TL_LANG']['tl_module']['reference_legend'] = 'Referenční stránka';
$GLOBALS['TL_LANG']['tl_module']['redirect_legend'] = 'Nastavení přesměrování';
$GLOBALS['TL_LANG']['tl_module']['template_legend'] = 'Nastavení předlohy';
$GLOBALS['TL_LANG']['tl_module']['config_legend'] = 'Nastavení mudulu';
$GLOBALS['TL_LANG']['tl_module']['include_legend'] = 'Zahrnout nastavení';
$GLOBALS['TL_LANG']['tl_module']['source_legend'] = 'Soubory a adresáře';
$GLOBALS['TL_LANG']['tl_module']['interact_legend'] = 'Interaktivní flashová videa';
$GLOBALS['TL_LANG']['tl_module']['html_legend'] = 'Text/HTML';
$GLOBALS['TL_LANG']['tl_module']['protected_legend'] = 'Chráněný přístup';
$GLOBALS['TL_LANG']['tl_module']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_module']['email_legend'] = 'Nastavení e-mailu';
$GLOBALS['TL_LANG']['tl_module']['header'] = 'Záhlaví';
$GLOBALS['TL_LANG']['tl_module']['left'] = 'Levý sloupec';
$GLOBALS['TL_LANG']['tl_module']['main'] = 'Hlavní sloupec';
$GLOBALS['TL_LANG']['tl_module']['right'] = 'Pravý sloupec';
$GLOBALS['TL_LANG']['tl_module']['footer'] = 'Zápatí';
$GLOBALS['TL_LANG']['tl_module']['internal'] = 'Vnitřní soubor';
$GLOBALS['TL_LANG']['tl_module']['external'] = 'Externí internetová adresa';
$GLOBALS['TL_LANG']['tl_module']['new'] = array('Přidat modul', 'Přidat modul');
$GLOBALS['TL_LANG']['tl_module']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k modulu ID %s');
$GLOBALS['TL_LANG']['tl_module']['edit'] = array('Editovat modul', 'Editovat modul ID %s');
$GLOBALS['TL_LANG']['tl_module']['cut'] = array('Přesunout modul', 'Přesunout modul ID %s');
$GLOBALS['TL_LANG']['tl_module']['copy'] = array('Duplikovat modul', 'Duplikovat modul ID %s');
$GLOBALS['TL_LANG']['tl_module']['delete'] = array('Smazat modul', 'Smazat modul ID %s');
$GLOBALS['TL_LANG']['tl_module']['editheader'] = array('Upravit vzhled', 'Upravit nastavení vzhledu');
$GLOBALS['TL_LANG']['tl_module']['pasteafter'] = array('Vložit sem', 'Vložit za modul ID %s');

$GLOBALS['TL_LANG']['tl_module']['disableCaptcha'] = array('Vypnout bezpečnostní otázku', 'Zde můžete vypnout bezpečnostní otázku (nedoporučeno).');
$GLOBALS['TL_LANG']['tl_module']['reg_groups'] = array('Skupiny členů', 'Prosím zařaďte uživatele do jedné nebo více skupin.');
$GLOBALS['TL_LANG']['tl_module']['reg_allowLogin'] = array('Povolit přihlášení', 'Pokud vyberete tuto volbu, nový uživatelé budou schopni se přihlásit pod svým uživatelským jménem a heslem.');
$GLOBALS['TL_LANG']['tl_module']['reg_skipName'] = array('Neptat se na uživatelské jméno', 'Nebude požadováno zadání uživatelského jména.');
$GLOBALS['TL_LANG']['tl_module']['reg_close'] = array('Způsob', 'Zde určíte, jakým způsobem bude provedeno smazání.');
$GLOBALS['TL_LANG']['tl_module']['reg_assignDir'] = array('Vytvořit domovský adresář.', 'Vyberte tuto volbu k automatickému vytváření domovského adresáře uživatele.');
$GLOBALS['TL_LANG']['tl_module']['reg_homeDir'] = array('Domovský adresář', 'Prosím vyberte rodičovský adresář k uživatelským adresářům.');
$GLOBALS['TL_LANG']['tl_module']['reg_activate'] = array('Poslat aktivační e-mail', 'Vyberte tuto volbu pokud chcete poslat aktivační e-mail registrovaným uživatelům.');
$GLOBALS['TL_LANG']['tl_module']['reg_jumpTo'] = array('Stránka s potvrzením', 'Vyberte prosím stránku, na níž bude uživatel přesměrován po úspěšném přihlášení.');
$GLOBALS['TL_LANG']['tl_module']['reg_text'] = array('Aktivační e-mail', 'Můžete použít <em>##domain##</em> (jméno domény), <em>##link##</em> (aktivační link) a jakékoliv pole "input" (např. <em>##příjmení##</em>).');
$GLOBALS['TL_LANG']['tl_module']['reg_password'] = array('Mail s heslem', 'Můžete použít <em>##domain##</em> (jméno domény), <em>##link##</em> (aktivační link) a jakékoliv pole "input" (např. <em>##příjmení##</em>).');
$GLOBALS['TL_LANG']['tl_module']['account_legend'] = 'Nastavení účtu';
$GLOBALS['TL_LANG']['tl_module']['emailText'] = array('Vaše registrace na %s', 'Děkujeme Vám za to, že jste se registrovali na naší ##domain## stránce. Pro dokončení registrace klikněte prosím na tento odkaz ##link##, aby se mohl zaktivovat Váš účet. Pokud tak nechcete učinit, ignorujte prosím tento mail.');
$GLOBALS['TL_LANG']['tl_module']['passwordText'] = array('Vyžádání Vašeho hesla na %s', 'Požádali jste o zaslání nového hesla pro ##domain##. Pro odeslání nového hesla kliknětě prosím na následující odkaz ##link##. Nedostanete-li tento mail, obraťte se prosím na správce webu.');
$GLOBALS['TL_LANG']['tl_module']['close_deactivate'] = 'Vypnutí účtu';
$GLOBALS['TL_LANG']['tl_module']['close_delete'] = 'Nenávratné smazání účtu';

$GLOBALS['TL_LANG']['tl_module']['rss_cache'] = array('Časový limit vyrovnávací paměti', 'Zde můžete určit, jak dlouho bude RSS kanál uložen ve vyrovnávací paměti.');
$GLOBALS['TL_LANG']['tl_module']['rss_feed'] = array('URL kanálu', 'Prosím vložte URL jednoho nebo více RSS kanálů.');
$GLOBALS['TL_LANG']['tl_module']['rss_template'] = array('Šablona kanálu', 'Zde můžete vybrat šablonu kanálu.');
$GLOBALS['TL_LANG']['tl_module']['rss_numberOfItems'] = array('Počet položek', 'Zde můžete omezit počet zobrazovaných položek. Nastavte 0 pro zobrazení všech.');

?>