<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_settings']['websiteTitle'] = array('Název stránky', 'Zadejte prosím název stránky');
$GLOBALS['TL_LANG']['tl_settings']['adminEmail'] = array('Emailová adresa administrátora systému', 'Zadejte emailovou adresu administrátora systému');
$GLOBALS['TL_LANG']['tl_settings']['dateFormat'] = array('Formát datumu', 'Zadejte formát data jako je použito v PHP funkci date()');
$GLOBALS['TL_LANG']['tl_settings']['timeFormat'] = array('Formát času', 'Zadejte formát času jako je použito v PHP funkci date()');
$GLOBALS['TL_LANG']['tl_settings']['datimFormat'] = array('Formát data a času', 'Zadejte formát data a času jako je použito v PHP funkci date()');
$GLOBALS['TL_LANG']['tl_settings']['timeZone'] = array('Časová zóna', 'Vyberte vaši časovou zónu');
$GLOBALS['TL_LANG']['tl_settings']['websitePath'] = array('Relativní cesta k Contao adresáři', 'Relativní cestu k adresáři Contao běžně automaticky nastaví instalační nástroj.');
$GLOBALS['TL_LANG']['tl_settings']['characterSet'] = array('Znaková sada', 'Zadejte znakovou sadu. Je doporučeno použít UTF-8 k tomu aby zvláštní znaky byly zobrazeny korektně. Neměňte znakovou sadu pokud vaše zkušenosti nezobrazují chyby.');
$GLOBALS['TL_LANG']['tl_settings']['customSections'] = array('Vlastní layoutové elementy', 'Zde můžete zadat vlastní layoutové elementy oddělené čárkou.');
$GLOBALS['TL_LANG']['tl_settings']['disableCron'] = array('Vypnout výchozí rozvrh údržby systému', 'Vypne pravidelný rozvrh údržby systému. V tom případě budete muset sami nastavit jiný rozvrh.');
$GLOBALS['TL_LANG']['tl_settings']['minifyMarkup'] = array('Zkomprimovat markup', 'Zkomprimovat markup HTML před odesláním do prohlížeče (vyžaduje rozšíření »PHP tidy«.');
$GLOBALS['TL_LANG']['tl_settings']['gzipScripts'] = array('Zkomprimovat scripta', 'Vytvoří zkomprimovat verzi kaskádovitých stylů (CSS) a JavaScriptových souborů. Je potřeba mít povolené využívání .htaccess souborů.');
$GLOBALS['TL_LANG']['tl_settings']['resultsPerPage'] = array('Počet položek na stránku', 'Zde můžete určit počet položek zobrazovaných na stránce v backendu');
$GLOBALS['TL_LANG']['tl_settings']['maxResultsPerPage'] = array('Maximální počet položek na stránku', 'Tato možnost přepíše, pokud návštěvník stránek zvolí "zobrazit všechny záznamy".');
$GLOBALS['TL_LANG']['tl_settings']['doNotCollapse'] = array('Nesbalovat elementy', 'Nesbalovat elementy v backendu a v náhledu.');
$GLOBALS['TL_LANG']['tl_settings']['urlSuffix'] = array('Přípona vytvořených stránek', 'Přípona bude přidána ke každému názvu stránky při převodu na statické stránky. (např. index.html)');
$GLOBALS['TL_LANG']['tl_settings']['cacheMode'] = array('Modus cachování', 'Zde můžete vybrat modus cachování.');
$GLOBALS['TL_LANG']['tl_settings']['privacyAnonymizeIp'] = array('Anonymizovat IP adresu', 'Anonymizovat všechny IP adresy, které jsou uloženy v databázi, kromě <em>tl_session</em> tabulky (tato IP adresa je spojena s aktuálním sezením z bezpečnostních důvodů).');
$GLOBALS['TL_LANG']['tl_settings']['privacyAnonymizeGA'] = array('Anonymizovat Google Analytics', 'Anonymizovat IP adresy, které se zasílají na Google Analytics.');
$GLOBALS['TL_LANG']['tl_settings']['rewriteURL'] = array('Přepsat URL', 'Contao bude přepisovat všechny stránky do statického kódu HTML. Tato funkce vyžaduje zapnutou modus "mod_rewrite". Přejmenujte ".htaccess.default" na ".htaccess" a v případně nutnosti přidejte nastavení pro RewriteBase.');
$GLOBALS['TL_LANG']['tl_settings']['addLanguageToUrl'] = array('Přidat jazyk do URL', 'Přidat jazykový řetězec jako první URL parametr (např. <em>http://domena.tld/en/</em>).');
$GLOBALS['TL_LANG']['tl_settings']['doNotRedirectEmpty'] = array('Nepřesměrovávat prazdné URL', 'Místo přesměřování na kořenovou stránku daného jazyka bude zobrazená prázdná stránka (nedoporučeno).');
$GLOBALS['TL_LANG']['tl_settings']['useAutoItem'] = array('Použít auto_item parametr', 'Přeskočit v řádku adresy stránky <em>items</em> nebo <em>events</em> a přidat do něj hodnotu <em>auto_item</em>.');
$GLOBALS['TL_LANG']['tl_settings']['disableAlias'] = array('Vypnout použití aliasů stránek', 'Použijí se číselné ID stránek namísto jejich aliasů.');
$GLOBALS['TL_LANG']['tl_settings']['allowedTags'] = array('Povolené HTML značky', 'Sem můžete uvést seznam povolených znaků HTML, které nebudou odstraňované.');
$GLOBALS['TL_LANG']['tl_settings']['debugMode'] = array('Ladící mód', 'Zobrazí na obrazovce určité informace celého procesu, např. spojení s databází nebo zaslané příkazy.');
$GLOBALS['TL_LANG']['tl_settings']['coreOnlyMode'] = array('Spustit v nouzovém režimu', 'Spustit Contao v nouzovém režimu a nahraj jen základní moduly.');
$GLOBALS['TL_LANG']['tl_settings']['lockPeriod'] = array('Čekací doba při uzamčení účtu', 'Účet může být uzamčen po 3krát po sobě špatně zadaném hesle.');
$GLOBALS['TL_LANG']['tl_settings']['displayErrors'] = array('Zobrazit chybové zprávy', 'Zobrazí chybové zprávy na obrazovce (není doporučeno pro produktivní stránky).');
$GLOBALS['TL_LANG']['tl_settings']['logErrors'] = array('Zapisuj chybové hlášky', 'Zapisuj chybové hlášky do log souboru (<em>system/logs/error.log</em>).');
$GLOBALS['TL_LANG']['tl_settings']['disableRefererCheck'] = array('Vypnout sledování referer', 'Nekontrolovat adresu zadavatele při odeslání formuláře. Upozornění: jisté bezpečnostní riziko!');
$GLOBALS['TL_LANG']['tl_settings']['disableIpCheck'] = array('Vypnout sledování IP', 'Neomezovat používání systému na adresy IP. Upozornění: jde o bezpečnostní riziko!');
$GLOBALS['TL_LANG']['tl_settings']['allowedDownload'] = array('Povolené druhy stažitelných souborů', 'Zde můžete uvést seznam druhů stažitelných souborů oddělených čárkou.');
$GLOBALS['TL_LANG']['tl_settings']['validImageTypes'] = array('Povolené druhy obrázkových souborů', 'Zde můžete uvést seznam druhů obrázkových souborů oddělených čárkou.');
$GLOBALS['TL_LANG']['tl_settings']['editableFiles'] = array('Povolené druhy upravitelných souborů', 'Zde můžete uvést seznam druhů upravitelných souborů oddělených čárkou.');
$GLOBALS['TL_LANG']['tl_settings']['templateFiles'] = array('Povolené druhy šablon', 'Zde můžete zadat, jaké druhy šablon bude systém podporovat.');
$GLOBALS['TL_LANG']['tl_settings']['maxImageWidth'] = array('Maximální velikost frontendu', 'Je-li velikost obrázků nebo videí větší než uvedená velikost, budou automaticky zmenšené na toto měřítko.');
$GLOBALS['TL_LANG']['tl_settings']['jpgQuality'] = array('Kvalita náhledu', 'Zadejte kvalitu náhledu v procentech (použije se pouze na JPG obrázky)');
$GLOBALS['TL_LANG']['tl_settings']['gdMaxImgWidth'] = array('Maximální šírka GD-obrázků', 'Zde můžete zadat maximální šířku obrázků, kterou se pokusí nastavit GD-knihovna.');
$GLOBALS['TL_LANG']['tl_settings']['gdMaxImgHeight'] = array('Maximální výška GD-obrázků', 'Zde můžete zadat maximální výšku obrázků, kterou se pokusí nastavit GD-knihovna.');
$GLOBALS['TL_LANG']['tl_settings']['uploadPath'] = array('Adresář souborů', 'Zadejte relativní cestu k adresáři souborů (výchozí je tl_files)');
$GLOBALS['TL_LANG']['tl_settings']['uploadTypes'] = array('Typy přenositelných souborů', 'Zde můžete uvést seznam druhů přenositelných souborů oddělených čárkou.');
$GLOBALS['TL_LANG']['tl_settings']['uploadFields'] = array('Počet nahrávání souborů zároveň', 'Zadejte počet souborů, které můžou být nahrávány ve stejný čas');
$GLOBALS['TL_LANG']['tl_settings']['maxFileSize'] = array('Maximální velikost nahrávaného souboru', 'Zadejte maximální velikost nahrávaného souboru v bytech (výchozí jsou 2 MB = 2048 kB = 2048000 bytů)');
$GLOBALS['TL_LANG']['tl_settings']['imageWidth'] = array('Maximální šířka obrázku', 'Zadejte maximální šířku obrázku');
$GLOBALS['TL_LANG']['tl_settings']['imageHeight'] = array('Maximální výška obrázku', 'Zadejte maximální výšku obrázku v pixelech, které se budou přenášet na server do určeného adresáře.');
$GLOBALS['TL_LANG']['tl_settings']['enableSearch'] = array('Aktivovat vyhledávání', 'Indexování stránek. Tím se pak v nich může vyhledávat.');
$GLOBALS['TL_LANG']['tl_settings']['indexProtected'] = array('Indexovat chráněné stránky', 'Použijte této funkce s jistou opatrností a vždy z toho osobní stránky!');
$GLOBALS['TL_LANG']['tl_settings']['useSMTP'] = array('Použít SMTP k posílání mailů', 'Použít SMTP pro odesílání mailů namísto funkce PHP mail().');
$GLOBALS['TL_LANG']['tl_settings']['smtpHost'] = array('Jméno poskytovatel SMTP', 'Zadejte jméno poskytovatele Vašeho SMTP serveru (výchozí je localhost)');
$GLOBALS['TL_LANG']['tl_settings']['smtpUser'] = array('Uživatelské jméno pro SMTP', 'Pokud váš SMTP server vyžaduje autentizaci zadejte uživatelské jméno');
$GLOBALS['TL_LANG']['tl_settings']['smtpPass'] = array('Heslo pro SMTP', 'Pokud váš SMTP server vyžaduje autentizaci zadejte heslo');
$GLOBALS['TL_LANG']['tl_settings']['smtpEnc'] = array('Zabezpečení SMTP', 'Zde můžete zvolit zabezpečovací metodu přenosu dat (SSL nebo TLS).');
$GLOBALS['TL_LANG']['tl_settings']['smtpPort'] = array('Číslo portu SMTP', 'Zadejte číslo portu vašeho SMTP serveru (výchozí je 25 nebo 465 pro SSL)');
$GLOBALS['TL_LANG']['tl_settings']['inactiveModules'] = array('Neaktivní rozšíření', 'Zde můžete zvolit, jaká rozšíření mají být aktivní nebo ne.');
$GLOBALS['TL_LANG']['tl_settings']['undoPeriod'] = array('Doba ukládání pro obnovení provedených změn', 'Zde můžete uvést dobu, po kterou budou uchovávány provedené změny. (24 hodin = 86400 sekund).');
$GLOBALS['TL_LANG']['tl_settings']['versionPeriod'] = array('Doba ukládání verzí', 'Zde můžete uvést dobu, po kterou budou uchovávány rozličné verze záznamů (90 dní = 7776000 sekund).');
$GLOBALS['TL_LANG']['tl_settings']['logPeriod'] = array('Doba ukládání zpráv systému', 'Zde můžete uvést dobu, po kterou budou uchovávány zprávy systému (14 dní = 1209600 sekund).');
$GLOBALS['TL_LANG']['tl_settings']['sessionTimeout'] = array('Doba prodlévání', 'Zde můžete uvést dobu, po kterou budou uchovávány prodlevy (60 minut = 3600 sekund).');
$GLOBALS['TL_LANG']['tl_settings']['autologin'] = array('Doba automatického přihlášení', 'Zde můžete uvést dobu, po kterou se bude moci člen automaticky přihlašovat do frontendu. (90 dnů = 7776000 sekund).');
$GLOBALS['TL_LANG']['tl_settings']['defaultUser'] = array('Výchozí autor stránky', 'Zde můžete uvést uživatele, který bude určený jako výchozí autor stránek.');
$GLOBALS['TL_LANG']['tl_settings']['defaultGroup'] = array('Výchozí skupina autorů', 'Zde můžete vybrat skupiny, která bude určená jako výchozí autor stránek.');
$GLOBALS['TL_LANG']['tl_settings']['defaultChmod'] = array('Výchozí přístupová práva', 'Zvolte prosím výchozí přístupová práva pro stránky a články.');
$GLOBALS['TL_LANG']['tl_settings']['liveUpdateBase'] = array('Adresa služby Live Update', 'Sem můžete zadat adresu služby Live Update');
$GLOBALS['TL_LANG']['tl_settings']['title_legend'] = 'Název webové stránky';
$GLOBALS['TL_LANG']['tl_settings']['date_legend'] = 'Datum a čas';
$GLOBALS['TL_LANG']['tl_settings']['global_legend'] = 'Globální nastavení';
$GLOBALS['TL_LANG']['tl_settings']['backend_legend'] = 'Nastavení backendu';
$GLOBALS['TL_LANG']['tl_settings']['frontend_legend'] = 'Nastavení frontendu';
$GLOBALS['TL_LANG']['tl_settings']['cache_legend'] = 'Nastaveni mezipaměti';
$GLOBALS['TL_LANG']['tl_settings']['privacy_legend'] = 'Nastaveni soukromí';
$GLOBALS['TL_LANG']['tl_settings']['security_legend'] = 'Bezpečnostní nastavení';
$GLOBALS['TL_LANG']['tl_settings']['files_legend'] = 'Soubory a obrázky';
$GLOBALS['TL_LANG']['tl_settings']['uploads_legend'] = 'Nastavení přenosu dat';
$GLOBALS['TL_LANG']['tl_settings']['search_legend'] = 'Nastavení vyhledávání';
$GLOBALS['TL_LANG']['tl_settings']['smtp_legend'] = 'Nastavení SMTP';
$GLOBALS['TL_LANG']['tl_settings']['ftp_legend'] = 'Nastavení Safe Mode Hack';
$GLOBALS['TL_LANG']['tl_settings']['modules_legend'] = 'Neaktivní rozšíření';
$GLOBALS['TL_LANG']['tl_settings']['timeout_legend'] = 'Doba ukládání';
$GLOBALS['TL_LANG']['tl_settings']['chmod_legend'] = 'Výchozí přístupová práva';
$GLOBALS['TL_LANG']['tl_settings']['update_legend'] = 'Live Update';
$GLOBALS['TL_LANG']['tl_settings']['static_legend'] = 'Zdroj statistik';
$GLOBALS['TL_LANG']['tl_settings']['edit'] = 'Upravit lokální konfiguraci';
$GLOBALS['TL_LANG']['tl_settings']['both'] = 'Použít cache prohlížeče a serveru';
$GLOBALS['TL_LANG']['tl_settings']['server'] = 'Použít jen cache serveru';
$GLOBALS['TL_LANG']['tl_settings']['browser'] = 'Použít jen cache prohlížeče';
$GLOBALS['TL_LANG']['tl_settings']['none'] = 'Vypnout cachování';

?>