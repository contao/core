<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_maintenance']['cacheTables'] = array('Vyčistit cache', 'Vyberte zdroje z cache které chcete vyčistit');
$GLOBALS['TL_LANG']['tl_maintenance']['frontendUser'] = array('Uživatel frontendu', 'Aby se daly indikovat chráněné stránky, musí být přihlášený alespoň jeden uživatel frontendu.');
$GLOBALS['TL_LANG']['tl_maintenance']['clearCache'] = 'Vyčistit cache';
$GLOBALS['TL_LANG']['tl_maintenance']['clearHtml'] = 'Adresář systému/html';
$GLOBALS['TL_LANG']['tl_maintenance']['clearScripts'] = 'Adresář systému/scripts';
$GLOBALS['TL_LANG']['tl_maintenance']['clearTemp'] = 'Temp adresář';
$GLOBALS['TL_LANG']['tl_maintenance']['clearXml'] = 'Přetvořit XML mapu stránek';
$GLOBALS['TL_LANG']['tl_maintenance']['clearCss'] = 'Soubory kaskádovitých stylů CSS';
$GLOBALS['TL_LANG']['tl_maintenance']['cacheCleared'] = 'Chache byla vyčištěna';
$GLOBALS['TL_LANG']['tl_maintenance']['liveUpdate'] = 'Online aktualizace';
$GLOBALS['TL_LANG']['tl_maintenance']['liveUpdateId'] = 'Online aktualizace ID';
$GLOBALS['TL_LANG']['tl_maintenance']['toLiveUpdate'] = 'Přejít na online aktualizace';
$GLOBALS['TL_LANG']['tl_maintenance']['upToDate'] = 'Tato verze %s Contao je nejnovější dostupná verze';
$GLOBALS['TL_LANG']['tl_maintenance']['newVersion'] = 'Je dostupná nová verze Contao %s';
$GLOBALS['TL_LANG']['tl_maintenance']['betaVersion'] = 'Nemůžete aktualizovat beta verzi přes live update';
$GLOBALS['TL_LANG']['tl_maintenance']['emptyLuId'] = 'Zadejte vaše ID online aktualizace';
$GLOBALS['TL_LANG']['tl_maintenance']['notWriteable'] = 'Do temp adresáře (systém/tmp) se nedá zapisovat';
$GLOBALS['TL_LANG']['tl_maintenance']['changelog'] = 'Prohlédnout si log změn';
$GLOBALS['TL_LANG']['tl_maintenance']['runLiveUpdate'] = 'Spustit aktualizaci';
$GLOBALS['TL_LANG']['tl_maintenance']['toc'] = 'Obsah této aktualizace';
$GLOBALS['TL_LANG']['tl_maintenance']['backup'] = 'Zálohováné soubory';
$GLOBALS['TL_LANG']['tl_maintenance']['update'] = 'Aktualizované soubory';
$GLOBALS['TL_LANG']['tl_maintenance']['searchIndex'] = 'Přetvořit vyhledávací index';
$GLOBALS['TL_LANG']['tl_maintenance']['indexSubmit'] = 'Přetvořit index';
$GLOBALS['TL_LANG']['tl_maintenance']['noSearchable'] = 'Nebyla nalezena žádná prohledávatelná';
$GLOBALS['TL_LANG']['tl_maintenance']['indexNote'] = 'Počkejte prosím, dokud se stránka nenačte, než začne pokračovat v práci!';
$GLOBALS['TL_LANG']['tl_maintenance']['indexLoading'] = 'Počkejte prosím, než se se vytvoří nový index pro vyhledávání.';
$GLOBALS['TL_LANG']['tl_maintenance']['indexComplete'] = 'Index pro vyhledávání byl přestaven. Můžete pokračovat v práci.';
$GLOBALS['TL_LANG']['tl_maintenance']['updateHelp'] = 'Zadejte sem prosím Vaší %s.';

?>