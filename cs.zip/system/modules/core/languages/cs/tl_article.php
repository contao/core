<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_article']['title'] = array('Název', 'Prosím zadejte název článku');
$GLOBALS['TL_LANG']['tl_article']['alias'] = array('Alias článku', 'Alias článku je unikátní odkaz na článek, který může být volán místo ID článku.');
$GLOBALS['TL_LANG']['tl_article']['author'] = array('Autor', 'Prosím zadejte jméno autora.');
$GLOBALS['TL_LANG']['tl_article']['inColumn'] = array('Zobrazit v', 'Prosím přiřaďte článek do sloupce nebo hlavičky nebo zápatí');
$GLOBALS['TL_LANG']['tl_article']['keywords'] = array('Klíčová slova', 'Zde můžete zadat seznam klíčových slov oddělených čárkou. Klíčová slova, nicméně, již nejsou relevantní pro většinu vyhledávačů (včetně Google).');
$GLOBALS['TL_LANG']['tl_article']['teaserCssID'] = array('Styl ukázky články CSS/ID', 'Zde můžete nastavit ID nebo více tříd kaskádového stylu pro ukázku daného elementu.');
$GLOBALS['TL_LANG']['tl_article']['showTeaser'] = array('Zobrazit ukázku', 'Pokud je zde více článků, zobrazí místo článku ukázku.');
$GLOBALS['TL_LANG']['tl_article']['teaser'] = array('Ukázka', 'Ukázka může být zobrazena automaticky nebo s obsahovým prvkem ukázka článku');
$GLOBALS['TL_LANG']['tl_article']['printable'] = array('Tisknutelné', 'Tisknout článek jako PDF (kaskádový styl s typem print)');
$GLOBALS['TL_LANG']['tl_article']['cssID'] = array('ID kaskádováho stylu a třída', 'Můžete zadat ID kaskádového stylu a jednu nebo více tříd kaskádového stylu (prvek class) k tomu, aby jste upravili článek pomocí CSS.');
$GLOBALS['TL_LANG']['tl_article']['space'] = array('Mezera před a po', 'Prosím zadejte mezeru před a po článku v pixelech.');
$GLOBALS['TL_LANG']['tl_article']['published'] = array('Publikovat', 'Tímto se daný článek zveřejní.');
$GLOBALS['TL_LANG']['tl_article']['start'] = array('Zobrazit od', 'Nezobrazí článek na webové stránce před zadaným dnem.');
$GLOBALS['TL_LANG']['tl_article']['stop'] = array('Zobrazit do', 'Nezobrazí článek na webové stránce po zadaném dni.');
$GLOBALS['TL_LANG']['tl_article']['tstamp'] = array('Změněno', 'Datum a čas poslední změny');
$GLOBALS['TL_LANG']['tl_article']['title_legend'] = 'Název a autor';
$GLOBALS['TL_LANG']['tl_article']['layout_legend'] = 'Klíčová slova pro hledání';
$GLOBALS['TL_LANG']['tl_article']['teaser_legend'] = 'Úvodní text článku';
$GLOBALS['TL_LANG']['tl_article']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_article']['publish_legend'] = 'Zveřejnění';
$GLOBALS['TL_LANG']['tl_article']['print'] = 'Vytisknout tuto stránku';
$GLOBALS['TL_LANG']['tl_article']['pdf'] = 'Exportovat jako PDF';
$GLOBALS['TL_LANG']['tl_article']['facebook'] = 'Sdílet přes Facebook';
$GLOBALS['TL_LANG']['tl_article']['twitter'] = 'Sdílet přes Twitter';
$GLOBALS['TL_LANG']['tl_article']['header'] = 'Hlavička stránky';
$GLOBALS['TL_LANG']['tl_article']['left'] = 'Levý sloupec';
$GLOBALS['TL_LANG']['tl_article']['main'] = 'Hlavní sloupec';
$GLOBALS['TL_LANG']['tl_article']['right'] = 'Pravý sloupec';
$GLOBALS['TL_LANG']['tl_article']['footer'] = 'Zápatí';
$GLOBALS['TL_LANG']['tl_article']['new'] = array('Nový článek', 'Vytvořit nový článek');
$GLOBALS['TL_LANG']['tl_article']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k článku s ID %s');
$GLOBALS['TL_LANG']['tl_article']['edit'] = array('Editovat článek', 'Editovat článek s ID %s');
$GLOBALS['TL_LANG']['tl_article']['editheader'] = array('Upravit nastavení článku', 'Upravit nastavení ID %s článku');
$GLOBALS['TL_LANG']['tl_article']['copy'] = array('Duplikovat článek', 'Duplikovat článek s ID %s');
$GLOBALS['TL_LANG']['tl_article']['cut'] = array('Přesunout článek', 'Přesunout článek s ID %s');
$GLOBALS['TL_LANG']['tl_article']['delete'] = array('Smazat článek', 'Smazat článek s ID %s');
$GLOBALS['TL_LANG']['tl_article']['toggle'] = array('Publikovat / nepublikovat', 'Publikovat / nepublikovat článek ID %s');
$GLOBALS['TL_LANG']['tl_article']['pasteafter'] = array('Vložit za', 'Vložit za článek s ID %s');
$GLOBALS['TL_LANG']['tl_article']['pasteinto'] = array('Vložit do', 'Vložit do článku ID %s');

?>