<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_form']['title'] = array('Název', 'Prosím zadejte název formuláře');
$GLOBALS['TL_LANG']['tl_form']['alias'] = array('Zástupce formuláře', 'Zástupce formuláře lze použít místo k němu náležící identifikačního čísla.');
$GLOBALS['TL_LANG']['tl_form']['jumpTo'] = array('Skok na stránku', 'Zvolte prosím stránku, na kterou bude návštěvník přesměrován po úspěšným odeslání formuláře.');
$GLOBALS['TL_LANG']['tl_form']['sendViaEmail'] = array('Zaslat dat mailem', 'Zaslání údajů z formuláře mailem.');
$GLOBALS['TL_LANG']['tl_form']['recipient'] = array('Adresa příjemce', 'Lze vložit více mailových adres oddělených čárkou.');
$GLOBALS['TL_LANG']['tl_form']['subject'] = array('Předmět', 'Zadejte prosím předmět mailu.');
$GLOBALS['TL_LANG']['tl_form']['format'] = array('Formát dat', 'Zde určíte, jakým způsobem budou předány údaje z formuáře.');
$GLOBALS['TL_LANG']['tl_form']['raw'] = array('Čistá data', 'Údaje z formuláře budou odeslána jako neformátovaný text, přičemž se každý údaj z každého pole bude nacházet na jednom řádku.');
$GLOBALS['TL_LANG']['tl_form']['xml'] = array('Soubor XML', 'Údaje z formuláře budou připojená k mailu jako soubor XML.');
$GLOBALS['TL_LANG']['tl_form']['csv'] = array('Soubor CSV', 'Údaje z formuláře budou připojená k mailu jako soubor CSV.');
$GLOBALS['TL_LANG']['tl_form']['email'] = array('E-Mail', 'Budou irgnorovány všechny pole kromě <em>email</em>, <em>subject</em>, <em>message</em> a <em>cc</em> (carbon copy) a zaslány jako mail. Zasílání souborů je povolené.');
$GLOBALS['TL_LANG']['tl_form']['skipEmtpy'] = array('Vynechat prázdná pole', 'Nezobrazí nevyplněná pole ve vytvořeném mailu.');
$GLOBALS['TL_LANG']['tl_form']['storeValues'] = array('Uložit data', 'Uloží zadaná data do databáze.');
$GLOBALS['TL_LANG']['tl_form']['targetTable'] = array('Cílová tabulka', 'Cílová tabulka musí obsahovat pro každý údaje z formuláře jeden sloupec.');
$GLOBALS['TL_LANG']['tl_form']['method'] = array('Metoda přenosu dat', 'Výchozí metoda přenosu dat je POST.');
$GLOBALS['TL_LANG']['tl_form']['attributes'] = array('Kaskádovité styly ID/class', 'Sem můžete zadat ID nebo více kaskádovitých tříd (class)');
$GLOBALS['TL_LANG']['tl_form']['formID'] = array('ID formuláře', 'Díky ID formuláře lze ovládat jiný modul ContaoContao.');
$GLOBALS['TL_LANG']['tl_form']['tableless'] = array('Formátování bez tabulky', 'Formulář nebude naformátovaný v tabulce.');
$GLOBALS['TL_LANG']['tl_form']['allowTags'] = array('Povolit znaky HTML', 'Povolí použití znaků HTML v polích formuláře.');
$GLOBALS['TL_LANG']['tl_form']['tstamp'] = array('Datum revize', 'Datum a čas poslední revize');
$GLOBALS['TL_LANG']['tl_form']['title_legend'] = 'Název a přesměrování';
$GLOBALS['TL_LANG']['tl_form']['email_legend'] = 'Poslat údaje z formuláře';
$GLOBALS['TL_LANG']['tl_form']['store_legend'] = 'Uložit údaje z formuláře';
$GLOBALS['TL_LANG']['tl_form']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_form']['config_legend'] = 'Konfigurace formuláře';
$GLOBALS['TL_LANG']['tl_form']['new'] = array('Nový formulář', 'Vytvořit nový formulář');
$GLOBALS['TL_LANG']['tl_form']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k formůláři ID %s');
$GLOBALS['TL_LANG']['tl_form']['edit'] = array('Editovat formulář', 'Editovat formulář ID %s');
$GLOBALS['TL_LANG']['tl_form']['editheader'] = array('Upravit nastavení formuláře', 'Upravit nastavení formuláře ID %s');
$GLOBALS['TL_LANG']['tl_form']['copy'] = array('Duplikovat formulář', 'Duplikovat formulář ID %s');
$GLOBALS['TL_LANG']['tl_form']['delete'] = array('Smazat formulář', 'Smazat formulář ID %s');

?>