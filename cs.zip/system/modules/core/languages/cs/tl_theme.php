<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_theme']['name'] = array('Název vzhledu', 'Uveďte prosím název vzhledu.');
$GLOBALS['TL_LANG']['tl_theme']['author'] = array('Autor', 'Uveďte prosím jméno osoby, která tento vzhled navrhla.');
$GLOBALS['TL_LANG']['tl_theme']['folders'] = array('Adresáře', 'Vyberte prosím adresáře, které patří k tomuto vzhledu.');
$GLOBALS['TL_LANG']['tl_theme']['templates'] = array('Adresář předlohy', 'Zde můžete vybrat adresář předlohy, který bude exportovaný s daným vzhledem.');
$GLOBALS['TL_LANG']['tl_theme']['screenshot'] = array('Náhled', 'Zde můžete vybrat náhled vzhledu.');
$GLOBALS['TL_LANG']['tl_theme']['vars'] = array('Globální proměnné', 'Zde můžete nastavit globální proměnné pro kaskádovité styly vzhledu (např. <em>$red</em> -> <em>c00</em> nebo <em>$margin</em> -> <em>12px</em>).');
$GLOBALS['TL_LANG']['tl_theme']['source'] = array('Zdroj souborů', 'Zvolte prosím jeden nebo více souborů končících na ".cto".');
$GLOBALS['TL_LANG']['tl_theme']['tstamp'] = array('Změněno', 'Datum a čas poslední změny.');
$GLOBALS['TL_LANG']['tl_theme']['title_legend'] = 'Název a autor';
$GLOBALS['TL_LANG']['tl_theme']['config_legend'] = 'Nastavení';
$GLOBALS['TL_LANG']['tl_theme']['vars_legend'] = 'Globální proměnné';
$GLOBALS['TL_LANG']['tl_theme']['theme_imported'] = 'Vzhled "%s" byl importovaný.';
$GLOBALS['TL_LANG']['tl_theme']['checking_theme'] = 'Data vzhledu byla přidána.';
$GLOBALS['TL_LANG']['tl_theme']['tables_fields'] = 'Tabulky a pole';
$GLOBALS['TL_LANG']['tl_theme']['missing_field'] = 'Pole <strong>%s</strong> chybí v databázi, proto nebude imporotováno.';
$GLOBALS['TL_LANG']['tl_theme']['tables_ok'] = 'Tabulka byla úspěšně';
$GLOBALS['TL_LANG']['tl_theme']['custom_sections'] = 'Vlastní část rozvržení';
$GLOBALS['TL_LANG']['tl_theme']['missing_section'] = 'Část rozvržení <strong>%s</strong> není nadefinovaná v nastavení systému.';
$GLOBALS['TL_LANG']['tl_theme']['sections_ok'] = 'Sekce rozložení byly úspěšně zkontrolovány.';
$GLOBALS['TL_LANG']['tl_theme']['missing_xml'] = 'Vzhled "%s" je poškozený a nemůže se importovat.';
$GLOBALS['TL_LANG']['tl_theme']['custom_templates'] = 'Vlastní šablony';
$GLOBALS['TL_LANG']['tl_theme']['template_exists'] = 'Šablona <strong>"%s"</strong> existuje a bude přepsána.';
$GLOBALS['TL_LANG']['tl_theme']['templates_ok'] = 'Nejsou zjištěny žádné konflikty.';
$GLOBALS['TL_LANG']['tl_theme']['new'] = array('Nový vzhled', 'Vytvořit nový vzhled');
$GLOBALS['TL_LANG']['tl_theme']['show'] = array('Podrobnosti', 'Zobrazit podrobnosti k vzhledu ID %s');
$GLOBALS['TL_LANG']['tl_theme']['edit'] = array('Úprava vzhledu', 'Úprava vzhledu ID %s');
$GLOBALS['TL_LANG']['tl_theme']['delete'] = array('Smazat vzhled', 'Smazat vzhled ID %s');
$GLOBALS['TL_LANG']['tl_theme']['css'] = array('Kaskádovité styly', 'Úprava kaskádovitých stylů vzhledu ID %s');
$GLOBALS['TL_LANG']['tl_theme']['modules'] = array('Moduly', 'Úprava frontendových modulů vzhledu ID %s');
$GLOBALS['TL_LANG']['tl_theme']['layout'] = array('Rozvržení', 'Úprava rozvržení stránek vzhledu ID %s');
$GLOBALS['TL_LANG']['tl_theme']['importTheme'] = array('Importovat vzhled', 'Import nových vzhledů');
$GLOBALS['TL_LANG']['tl_theme']['exportTheme'] = array('Export', 'Exportovat vzhled ID %s');

?>