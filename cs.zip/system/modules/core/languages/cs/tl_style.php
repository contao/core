<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_style']['invisible'] = array('Skryté', 'Nexportovat formátování.');
$GLOBALS['TL_LANG']['tl_style']['selector'] = array('Selektor', 'Selektor určuje, k jakému elementu se dané formátování vztahuje.');
$GLOBALS['TL_LANG']['tl_style']['category'] = array('Kategorie', 'Kategorie lze použít k uskupení nadefinovaných styl v backendu.');
$GLOBALS['TL_LANG']['tl_style']['comment'] = array('Komentář', 'Sem můžete přidat komentář.');
$GLOBALS['TL_LANG']['tl_style']['size'] = array('Šířka a výška', 'šířka, výška (width, height, min-width, min-height, max-width a max-height)');
$GLOBALS['TL_LANG']['tl_style']['width'] = array('Šířka', 'Zde můžete zadat šířku elementu.');
$GLOBALS['TL_LANG']['tl_style']['height'] = array('Výška', 'Zde můžete zadat výšku elementu.');
$GLOBALS['TL_LANG']['tl_style']['minwidth'] = array('Minimální šířka', 'Zde můžete určit minimální šířku daného elementu.');
$GLOBALS['TL_LANG']['tl_style']['minheight'] = array('Minimální výška', 'Zde můžete určit minimální šířku daného elementu.');
$GLOBALS['TL_LANG']['tl_style']['maxwidth'] = array('Maximální šířka', 'Zde můžete určit maximální šířku daného elementu.');
$GLOBALS['TL_LANG']['tl_style']['maxheight'] = array('Maximální výška', 'Zde můžete určit maximální výšku daného elementu.');
$GLOBALS['TL_LANG']['tl_style']['positioning'] = array('Umístění', 'umístění (position), obtékání (float), smazání (clear), přetákání (overflow) a zobrazení (display).');
$GLOBALS['TL_LANG']['tl_style']['trbl'] = array('Umístění', 'Zde můžete určit umístění elementu - nahoře, vpravo, dole nebo vlevo.');
$GLOBALS['TL_LANG']['tl_style']['position'] = array('Typ umístění', 'Zde můžete zvolit typ umístění.');
$GLOBALS['TL_LANG']['tl_style']['floating'] = array('Obtékání (Float)', 'Zde můžete zvolit typ obtékání.');
$GLOBALS['TL_LANG']['tl_style']['clear'] = array('Smazání (Clear)', 'Zde můžete zvolit typ smazání (clear).');
$GLOBALS['TL_LANG']['tl_style']['overflow'] = array('Přetékání (Overflow)', 'Zde můžete zvolit typ přetékání (overflow).');
$GLOBALS['TL_LANG']['tl_style']['display'] = array('Zobrazení (Display)', 'Zde můžete vybrat typ zobrazení.');
$GLOBALS['TL_LANG']['tl_style']['alignment'] = array('Odsazení zvenčí, uvnitř a uspořádání', 'Margin, padding, align, vertical-align a text-align.');
$GLOBALS['TL_LANG']['tl_style']['margin'] = array('Margin (vnější odsazení)', 'Zde můžete zadat odsazení zeshora (top), zprava (right), zespodu (bottom) a zleva (left).');
$GLOBALS['TL_LANG']['tl_style']['padding'] = array('Padding (vnitřní odsazení)', 'Zde můžete zadat odsazení zeshora (top), zprava (right), zespodu (bottom) a zleva (left).');
$GLOBALS['TL_LANG']['tl_style']['align'] = array('Uspořádání elementu', 'Pro uspořádání elementu bude přepsán pravý a levý vnější odstup.');
$GLOBALS['TL_LANG']['tl_style']['verticalalign'] = array('Vertikální uspořádání', 'Zde můžete zvolit vertikální uspořádání.');
$GLOBALS['TL_LANG']['tl_style']['textalign'] = array('Umístění textu', 'Zde můžete zvolit horizontální uspořádání textu.');
$GLOBALS['TL_LANG']['tl_style']['background'] = array('Pozadí', 'Background-color, background-image, background-position a background-repeat.');
$GLOBALS['TL_LANG']['tl_style']['bgcolor'] = array('Barva pozadí', 'Zde můžete zadat hexidecimální barvu pozadí (např. ff0000 pro červenou).');
$GLOBALS['TL_LANG']['tl_style']['bgimage'] = array('Obrázek pozadí', 'Zde můžete uvést cestu k obrázku pozadí.');
$GLOBALS['TL_LANG']['tl_style']['bgposition'] = array('Umístění pozadí', 'Zde můžete vybrat pozici obrázku pozadí.');
$GLOBALS['TL_LANG']['tl_style']['bgrepeat'] = array('Opakování pozadí', 'Zde můžete vybrat možnost opakování.');
$GLOBALS['TL_LANG']['tl_style']['shadowsize'] = array('Velikost stínu', 'Zde můžete zadat umístění, odsazení a dosah stínu v ose X a Y.');
$GLOBALS['TL_LANG']['tl_style']['shadowcolor'] = array('Barva stínu', 'Zde můžete určit barvu stínu (např. ff0000 pro červenou) a také průhlednost v procentech (např. 75)');
$GLOBALS['TL_LANG']['tl_style']['gradientAngle'] = array('Druh přechodu', 'Zde můžete určit druh / průběh přechodu (např. <em>-45deg</em> nebo jeho začátek (např. <em>top</em> nebo <em>lef bottom</em>)');
$GLOBALS['TL_LANG']['tl_style']['gradientColors'] = array('Barva přechodu', 'Zde můžete určit jednotlivé barvy přechodu (např. <em>ffc 10% | f90 | f00</em>');
$GLOBALS['TL_LANG']['tl_style']['border'] = array('Rám', 'Border-width, border-style, border-color a border-collapse.');
$GLOBALS['TL_LANG']['tl_style']['borderwidth'] = array('Velikost rámu', 'Zde můžete zadat šířku rámu nahoře, vpravo, dole a vlevo.');
$GLOBALS['TL_LANG']['tl_style']['borderstyle'] = array('Styl rámu', 'Zde můžete zvolit styl rámu.');
$GLOBALS['TL_LANG']['tl_style']['bordercolor'] = array('Barva rámu', 'Zde můžete zadat hexidecimální barvu rámu (např. ff0000 pro červenou).');
$GLOBALS['TL_LANG']['tl_style']['borderradius'] = array('Zaoblení rohů rámu', 'Zde můžete určit poměr zabolení rohů rámu');
$GLOBALS['TL_LANG']['tl_style']['bordercollapse'] = array('Model rámu', 'Zde můžete zvolit model rámu.');
$GLOBALS['TL_LANG']['tl_style']['borderspacing'] = array('Odsazení rámu', 'Zde můžete určit odsazení rámu');
$GLOBALS['TL_LANG']['tl_style']['font'] = array('Písmo', 'Font-family, font-size, font-color, line-height, font-style a white-space.');
$GLOBALS['TL_LANG']['tl_style']['fontfamily'] = array('Druh písma', 'Zde můžete zadat seznam druhů písma oddělené čárkou.');
$GLOBALS['TL_LANG']['tl_style']['fontsize'] = array('Velikost písma', 'Zde můžete zadat velikost písma.');
$GLOBALS['TL_LANG']['tl_style']['fontcolor'] = array('Barva písma', 'Zde můžete zadat hexidecimální barvu písma (např. ff0000 pro červenou).');
$GLOBALS['TL_LANG']['tl_style']['lineheight'] = array('Výška řádku', 'Zde můžete určit výšku řádku.');
$GLOBALS['TL_LANG']['tl_style']['fontstyle'] = array('Styl písma', 'Zde můžete zvolit jeden nebo více stylů písma.');
$GLOBALS['TL_LANG']['tl_style']['whitespace'] = array('Vypnout automatická zalamování řádek', 'Nezalomovat řádky uvnitř elementu.');
$GLOBALS['TL_LANG']['tl_style']['texttransform'] = array('Velikost písmen', 'Zde můžete určit velikost písmen');
$GLOBALS['TL_LANG']['tl_style']['textindent'] = array('Odsazení textu', 'Zde můžete určit odsazení textu (výchozí: 0px)');
$GLOBALS['TL_LANG']['tl_style']['letterspacing'] = array('Odsazení mezi znaky', 'Zde můžete určit odsazení mezi znaky (výchozí: 0px)');
$GLOBALS['TL_LANG']['tl_style']['wordspacing'] = array('Odsazení mezi slovy', 'Zde můžete určit odsazení mezi slovy (výchozí: 0px)');
$GLOBALS['TL_LANG']['tl_style']['list'] = array('Styly seznamů', 'List-style-type a list-style-image.');
$GLOBALS['TL_LANG']['tl_style']['liststyletype'] = array('Symboly seznamů', 'Zde vyberte symbol seznamu.');
$GLOBALS['TL_LANG']['tl_style']['liststyleimage'] = array('Vlastní symbol', 'Zde můžete zadat cestu k vlastnímu symbolu.');
$GLOBALS['TL_LANG']['tl_style']['own'] = array('Vlastní kód', 'Zde můžete zadat vlastní kód kaskádovitého stylu.');
$GLOBALS['TL_LANG']['tl_style']['selector_legend'] = 'Selektor a kategorie';
$GLOBALS['TL_LANG']['tl_style']['size_legend'] = 'Rozměry';
$GLOBALS['TL_LANG']['tl_style']['position_legend'] = 'Umístění';
$GLOBALS['TL_LANG']['tl_style']['align_legend'] = 'Odsazení a uspořádání';
$GLOBALS['TL_LANG']['tl_style']['background_legend'] = 'Pozadí';
$GLOBALS['TL_LANG']['tl_style']['border_legend'] = 'Rám';
$GLOBALS['TL_LANG']['tl_style']['font_legend'] = 'Písmo';
$GLOBALS['TL_LANG']['tl_style']['list_legend'] = 'Seznam';
$GLOBALS['TL_LANG']['tl_style']['custom_legend'] = 'Vlastní kód';
$GLOBALS['TL_LANG']['tl_style']['normal'] = 'normální';
$GLOBALS['TL_LANG']['tl_style']['bold'] = 'tučné';
$GLOBALS['TL_LANG']['tl_style']['italic'] = 'kurzíva';
$GLOBALS['TL_LANG']['tl_style']['underline'] = 'podtržené';
$GLOBALS['TL_LANG']['tl_style']['notUnderlined'] = 'nepodtržené';
$GLOBALS['TL_LANG']['tl_style']['line-through'] = 'přeškrtnuté';
$GLOBALS['TL_LANG']['tl_style']['overline'] = 'nadtržené';
$GLOBALS['TL_LANG']['tl_style']['small-caps'] = 'malé kapitálky';
$GLOBALS['TL_LANG']['tl_style']['disc'] = 'tečka';
$GLOBALS['TL_LANG']['tl_style']['circle'] = 'kruh';
$GLOBALS['TL_LANG']['tl_style']['square'] = 'čtverec';
$GLOBALS['TL_LANG']['tl_style']['decimal'] = 'čísla';
$GLOBALS['TL_LANG']['tl_style']['upper-roman'] = 'latinská čísla velkými písmeny';
$GLOBALS['TL_LANG']['tl_style']['lower-roman'] = 'latinská čísla malými písmeny';
$GLOBALS['TL_LANG']['tl_style']['upper-alpha'] = 'velká písmena';
$GLOBALS['TL_LANG']['tl_style']['lower-alpha'] = 'malá písmena';
$GLOBALS['TL_LANG']['tl_style']['uppercase'] = 'velká písmena (majuskule)';
$GLOBALS['TL_LANG']['tl_style']['lowercase'] = 'všechna malá písmena (miniskule)';
$GLOBALS['TL_LANG']['tl_style']['capitalize'] = 'kapitálky';
$GLOBALS['TL_LANG']['tl_style']['none'] = 'žádný symbol';
$GLOBALS['TL_LANG']['tl_style']['new'] = array('Nový nadefinovaný styl', 'Vytvořit nový nadefinovaný styl');
$GLOBALS['TL_LANG']['tl_style']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k nadefinovému stylu ID %s');
$GLOBALS['TL_LANG']['tl_style']['edit'] = array('Upravit nadefinovaný styl', 'Upravit nadefinovaný styl ID %s');
$GLOBALS['TL_LANG']['tl_style']['cut'] = array('Přesunout naformátovaný styl', 'Přesunout nadefinovaný styl ID %s');
$GLOBALS['TL_LANG']['tl_style']['copy'] = array('Duplikovat nadefinovaný styl', 'Duplikovat nadefinovaný styl ID %s');
$GLOBALS['TL_LANG']['tl_style']['delete'] = array('Smazat nadefinovaný styl', 'Smazat nadefinovaný styl ID %s');
$GLOBALS['TL_LANG']['tl_style']['editheader'] = array('Upravit kaskádovitý styl', 'Upravit kaskádovité styly');
$GLOBALS['TL_LANG']['tl_style']['pasteafter'] = array('Vložit nahoru', 'Vložit za ID %s');
$GLOBALS['TL_LANG']['tl_style']['pastenew'] = array('Přidat nahoře', 'Přidat nové formátování za ID %s');
$GLOBALS['TL_LANG']['tl_style']['toggle'] = array('Změnit zobrazení', 'Změnit zobrazení formátování ID %s');

?>