<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_style_sheet']['name'] = array('Název', 'Zadejte prosím název kaskádovitého stylu.');
$GLOBALS['TL_LANG']['tl_style_sheet']['cc'] = array('Conditional comment', 'Conditional comment umožňuje nadefinování specifických stylů pro Internet Expolover.');
$GLOBALS['TL_LANG']['tl_style_sheet']['media'] = array('Typ média', 'Zvolte prosím druh média');
$GLOBALS['TL_LANG']['tl_style_sheet']['mediaQuery'] = array('Druh médii', 'Zde můžete určit, pro jaký druh médií je daný styl určený. <em>screen a (min-width:800px)</em>. Druh médií určuje, jak se změní obtékání či přetákání různých elementů.');
$GLOBALS['TL_LANG']['tl_style_sheet']['vars'] = array('Všeobecné proměnné', 'Zde můžete určit všeobecné proměnné pro daný styl (např. $red</em> -> <em>c00</em> nebo <em>$margin</em> -> <em>12px</em>)');
$GLOBALS['TL_LANG']['tl_style_sheet']['source'] = array('Zdroj souborů', 'Vyberte prosím jeden nebo více souborů z adresáře souborů.');
$GLOBALS['TL_LANG']['tl_style_sheet']['tstamp'] = array('Datum poslední úpravy', 'Datum a čas poslední úpravy');
$GLOBALS['TL_LANG']['tl_style_sheet']['title_legend'] = 'Název a mediální typ';
$GLOBALS['TL_LANG']['tl_style_sheet']['media_legend'] = 'Nastavení médií';
$GLOBALS['TL_LANG']['tl_style_sheet']['vars_legend'] = 'Globální proměnné';
$GLOBALS['TL_LANG']['tl_style_sheet']['css_imported'] = 'Kaskádovitý styl "%s" byl úspěšně importován.';
$GLOBALS['TL_LANG']['tl_style_sheet']['css_renamed'] = 'Kaskádovitý styl "%s" byl úspěšně importován jako "%s".';
$GLOBALS['TL_LANG']['tl_style_sheet']['new'] = array('Nový styl', 'Vytvořit nový styl');
$GLOBALS['TL_LANG']['tl_style_sheet']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti ke stylu ID %s');
$GLOBALS['TL_LANG']['tl_style_sheet']['edit'] = array('Upravit styl', 'Upravit styl ID %s');
$GLOBALS['TL_LANG']['tl_style_sheet']['editheader'] = array('Upravit nastavení stylů', 'Upravit nastavení stylu ID %s');
$GLOBALS['TL_LANG']['tl_style_sheet']['cut'] = array('Přesunout kaskádovitý styl', 'Přesunout kaskádovitý styl ID %s');
$GLOBALS['TL_LANG']['tl_style_sheet']['copy'] = array('Duplikovat styl', 'Duplikovat styl ID %s');
$GLOBALS['TL_LANG']['tl_style_sheet']['delete'] = array('Smazat styl', 'Smazat styl ID %s');
$GLOBALS['TL_LANG']['tl_style_sheet']['import'] = array('Import CSS', 'Importovat existující soubor CSS');

?>