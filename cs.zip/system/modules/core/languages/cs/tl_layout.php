<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_layout']['name'] = array('Název', 'Zadejte prosím název vzhledu.');
$GLOBALS['TL_LANG']['tl_layout']['fallback'] = array('Výchozí vzhled', 'Nastavit jako výchozí vzhled');
$GLOBALS['TL_LANG']['tl_layout']['header'] = array('Přidat hlavičku stránky', 'Tímto krokem přidáte hlavičku do vzhledu stránky.');
$GLOBALS['TL_LANG']['tl_layout']['headerHeight'] = array('Výška hlavičky', 'Zadejte prosím výšku hlavičky stránky.');
$GLOBALS['TL_LANG']['tl_layout']['footer'] = array('Přidat zápatí stránky', 'Přidá zápatí ke vzhledu této stránky.');
$GLOBALS['TL_LANG']['tl_layout']['footerHeight'] = array('Výška zápatí', 'Zadejte prosím výšku zápatí stránky.');
$GLOBALS['TL_LANG']['tl_layout']['cols'] = array('Sloupečky.', 'Zvolte prosím počet sloupečků.');
$GLOBALS['TL_LANG']['tl_layout']['1cl'] = array('Jen hlavní sloupeček', 'zobrazí se jen jeden sloupečky.');
$GLOBALS['TL_LANG']['tl_layout']['2cll'] = array('Levý a hlavní sloupeček.', 'zobrazí dva sloupečky - s hlavním na pravé straně.');
$GLOBALS['TL_LANG']['tl_layout']['2clr'] = array('Hlavní a pravý sloupeček', 'zobrazí dva sloupečky - s hlavním na levé straně.');
$GLOBALS['TL_LANG']['tl_layout']['3cl'] = array('Hlavní, levý a pravý sloupec', 'zobrazí tři sloupečky - s hlavním uprostřed.');
$GLOBALS['TL_LANG']['tl_layout']['widthLeft'] = array('Šířka levého sloupečku', 'Zadejte prosím šířku levého sloupečku.');
$GLOBALS['TL_LANG']['tl_layout']['widthRight'] = array('Šířka pravého sloupce', 'Zadejte prosím šířku pravého sloupce.');
$GLOBALS['TL_LANG']['tl_layout']['sections'] = array('Vlastní elementy', 'Vlastní elementy můžou být určené v nastaveních systému.');
$GLOBALS['TL_LANG']['tl_layout']['sPosition'] = array('Umístění vlastních elementů', 'Zvolte prosím umístění vlastních elementů.');
$GLOBALS['TL_LANG']['tl_layout']['stylesheet'] = array('Kaskádové Styly', 'Zvolte prosím kaskádové styly, které chcete přidat do tohoto vzhledu.');
$GLOBALS['TL_LANG']['tl_layout']['skipTinymce'] = array('Nezahrnovat tl_files/tinymce.css', 'Nazačleňovat kaskádovité styly TinyMCE (tl_files/tinymce.css)');
$GLOBALS['TL_LANG']['tl_layout']['webfonts'] = array('Google web fonty', 'Zde můžete přidat Google web fonty na vaše webové stránky. Zvolte typ fontu bez URL (napr. <em>Ubuntu|Ubuntu+Mono</em>).');
$GLOBALS['TL_LANG']['tl_layout']['newsfeeds'] = array('Kanály Novinek', 'Zvolte prosím kanály, které chcete přidat do tohoto vzhledu.');
$GLOBALS['TL_LANG']['tl_layout']['calendarfeeds'] = array('Kanály Kalendáře', 'Zvolte prosím kanály, které chcete přidat do tohoto vzhledu.');
$GLOBALS['TL_LANG']['tl_layout']['modules'] = array('Připojené moduly', 'Máte-li vyplou Javu, ujistěte se, že jste veškeré úpravy uložili před úpravou této části.');
$GLOBALS['TL_LANG']['tl_layout']['template'] = array('Šablona stránky', 'Zde můžete zvolit šablonu stránky.');
$GLOBALS['TL_LANG']['tl_layout']['skipFramework'] = array('Vypnout CSS framework', 'Nenahravat Contao CSS framework. Generátor layoutu stránek v tomto pŕípadě nebude fungovat.');
$GLOBALS['TL_LANG']['tl_layout']['doctype'] = array('Druh dokumentu', 'Zvolte prosím typ dokumentu');
$GLOBALS['TL_LANG']['tl_layout']['mooSource'] = array('Zdroj MooTools', 'Můžete použít lokálních skriptů MooTools nebo je nahrát z jiného zdroje na internetu.');
$GLOBALS['TL_LANG']['tl_layout']['cssClass'] = array('Třída pro "body"', 'Zde můžete přidat k "body" vlastní třídy kaskádovitých stylů.');
$GLOBALS['TL_LANG']['tl_layout']['onload'] = array('Body onload', 'Sem můžete přidat atributy pro "body onload".');
$GLOBALS['TL_LANG']['tl_layout']['head'] = array('Dodatečné údaje pro', 'Zde můžete přidat vlastní tagy pro "head" stránky.');
$GLOBALS['TL_LANG']['tl_layout']['mootools'] = array('Předlohy MooTools', 'Zde můžete vybrat jeden nebo více předloh MooTools.');
$GLOBALS['TL_LANG']['tl_layout']['script'] = array('Vlastní kód JavaScriptu', 'Kód JavyScriptu, který bude vložen na konci stránky.');
$GLOBALS['TL_LANG']['tl_layout']['static'] = array('Statický vzhled', 'Vytvoří statický vzhled s pevnou šírkou a umístěním.');
$GLOBALS['TL_LANG']['tl_layout']['width'] = array('Celková šíře', 'Hodnota celkové šíře bude přidělena elementu "wrapper".');
$GLOBALS['TL_LANG']['tl_layout']['align'] = array('Uspořádání', 'Zvolte prosím uspořádání stránky.');
$GLOBALS['TL_LANG']['tl_layout']['title_legend'] = 'Název a standard';
$GLOBALS['TL_LANG']['tl_layout']['header_legend'] = 'Záhlaví a zápatí';
$GLOBALS['TL_LANG']['tl_layout']['column_legend'] = 'Nastavení sloupců';
$GLOBALS['TL_LANG']['tl_layout']['sections_legend'] = 'Vlastní prvky rozvržení stránky';
$GLOBALS['TL_LANG']['tl_layout']['style_legend'] = 'Styly';
$GLOBALS['TL_LANG']['tl_layout']['feed_legend'] = 'RSS/Kanál';
$GLOBALS['TL_LANG']['tl_layout']['modules_legend'] = 'Muduly frontendu';
$GLOBALS['TL_LANG']['tl_layout']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_layout']['script_legend'] = 'Nastavení skript';
$GLOBALS['TL_LANG']['tl_layout']['static_legend'] = 'Statický vzhled';
$GLOBALS['TL_LANG']['tl_layout']['moo_local'] = 'Použít lokálního souboru';
$GLOBALS['TL_LANG']['tl_layout']['moo_googleapis'] = 'Nahrát z googleapis.com';
$GLOBALS['TL_LANG']['tl_layout']['moo_fallback'] = 'Nahrát z googleapis.com s lokálním fallback';
$GLOBALS['TL_LANG']['tl_layout']['html5'] = 'HTML';
$GLOBALS['TL_LANG']['tl_layout']['xhtml_strict'] = 'XHTML Strict';
$GLOBALS['TL_LANG']['tl_layout']['xhtml_trans'] = 'XHTML Transitional';
$GLOBALS['TL_LANG']['tl_layout']['before'] = 'Po hlavičce stránky';
$GLOBALS['TL_LANG']['tl_layout']['main'] = 'Uvnitř hlavního sloupce';
$GLOBALS['TL_LANG']['tl_layout']['after'] = 'Před zápatím stránky';
$GLOBALS['TL_LANG']['tl_layout']['edit_styles'] = 'Upravit kaskádové styly';
$GLOBALS['TL_LANG']['tl_layout']['edit_module'] = 'Upravit modul';
$GLOBALS['TL_LANG']['tl_layout']['new'] = array('Nový vzhled', 'Vytvoří nový vzhled');
$GLOBALS['TL_LANG']['tl_layout']['show'] = array('Zobrazit podrobnosti', 'Zobrazí podrobnosti ke vzhledu ID %s');
$GLOBALS['TL_LANG']['tl_layout']['edit'] = array('Upravit vzhled', 'Upravit vzhled ID %s');
$GLOBALS['TL_LANG']['tl_layout']['cut'] = array('Přesunout rozvržení', 'Přesunout rozvržení ID %s');
$GLOBALS['TL_LANG']['tl_layout']['copy'] = array('Duplikovat vzhled', 'Duplikovat vzhled ID %s');
$GLOBALS['TL_LANG']['tl_layout']['delete'] = array('Smazat vzhled', 'Smazat vzhled ID %s');
$GLOBALS['TL_LANG']['tl_layout']['editheader'] = array('Upravit vzhled', 'Upravit nastavení vzhledu');

?>