<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_member']['firstname'] = array('Jméno', 'Zadejte jméno');
$GLOBALS['TL_LANG']['tl_member']['lastname'] = array('Přijmení', 'Zadejte přijmení');
$GLOBALS['TL_LANG']['tl_member']['dateOfBirth'] = array('Datum narození', 'Zadejte datum narození');
$GLOBALS['TL_LANG']['tl_member']['gender'] = array('Pohlaví', 'Vyberte pohlaví');
$GLOBALS['TL_LANG']['tl_member']['company'] = array('Společnost', 'Zadejte název společnosti');
$GLOBALS['TL_LANG']['tl_member']['street'] = array('Ulice', 'Zadejte ulici a číslo');
$GLOBALS['TL_LANG']['tl_member']['postal'] = array('PSČ', 'Zadejte PSČ');
$GLOBALS['TL_LANG']['tl_member']['city'] = array('Město', 'Zadejte město');
$GLOBALS['TL_LANG']['tl_member']['state'] = array('Kraj', 'Zadejte kraj');
$GLOBALS['TL_LANG']['tl_member']['country'] = array('Země', 'Vyberte zemi');
$GLOBALS['TL_LANG']['tl_member']['phone'] = array('Telefonní číslo', 'Zadejte telefonní číslo');
$GLOBALS['TL_LANG']['tl_member']['mobile'] = array('Číslo mobilního telefonu', 'Zadejte číslo mobilního telefonu');
$GLOBALS['TL_LANG']['tl_member']['fax'] = array('Číslo faxu', 'Zadejte číslo faxu');
$GLOBALS['TL_LANG']['tl_member']['email'] = array('Emailová adresa', 'Zadejte platnou emailovou adresu');
$GLOBALS['TL_LANG']['tl_member']['website'] = array('Webová adresa', 'Zadejte URL adresu stránky');
$GLOBALS['TL_LANG']['tl_member']['language'] = array('Jazyk', 'Vyberte jazyk');
$GLOBALS['TL_LANG']['tl_member']['groups'] = array('Skupina', 'Přiřaďte uživatele do jedné či více skupin');
$GLOBALS['TL_LANG']['tl_member']['login'] = array('Povolit přihlášení', 'Povolit přihlášení do front endu.');
$GLOBALS['TL_LANG']['tl_member']['username'] = array('Uživatelské jméno', 'Zadejte uživatelské jméno');
$GLOBALS['TL_LANG']['tl_member']['assignDir'] = array('Přiřadit domácí adresář', 'Zvolte tuto volbu k přiřazení domácího adresáře');
$GLOBALS['TL_LANG']['tl_member']['homeDir'] = array('Domácí adresář', 'Vyberte uživatelův domácí adresář');
$GLOBALS['TL_LANG']['tl_member']['disable'] = array('Deaktivovat', 'Pokud vyberete tuto volbu současný účet bude deaktivován');
$GLOBALS['TL_LANG']['tl_member']['start'] = array('Aktivovat k', 'Pokud zadáte datum současný účet bude aktivován k tomuto datu');
$GLOBALS['TL_LANG']['tl_member']['stop'] = array('Deaktivovat k', 'Pokud zadáte datum současný účet bude deaktivován k tomuto datu');
$GLOBALS['TL_LANG']['tl_member']['personal_legend'] = 'Osobní údaje';
$GLOBALS['TL_LANG']['tl_member']['address_legend'] = 'Adresa';
$GLOBALS['TL_LANG']['tl_member']['contact_legend'] = 'Kontakt';
$GLOBALS['TL_LANG']['tl_member']['groups_legend'] = 'Uživatelské skupiny';
$GLOBALS['TL_LANG']['tl_member']['login_legend'] = 'Přihlášení';
$GLOBALS['TL_LANG']['tl_member']['homedir_legend'] = 'Domovský adresář';
$GLOBALS['TL_LANG']['tl_member']['account_legend'] = 'Nastavení účtu';
$GLOBALS['TL_LANG']['tl_member']['personalData'] = 'Osobní data';
$GLOBALS['TL_LANG']['tl_member']['addressDetails'] = 'Detail adresy';
$GLOBALS['TL_LANG']['tl_member']['contactDetails'] = 'Kontakt';
$GLOBALS['TL_LANG']['tl_member']['loginDetails'] = 'Detail přihlášení';
$GLOBALS['TL_LANG']['tl_member']['new'] = array('Nový člen', 'Vytvořit nového člena');
$GLOBALS['TL_LANG']['tl_member']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k členovi ID %s');
$GLOBALS['TL_LANG']['tl_member']['edit'] = array('Editovat člena', 'Editovat člena ID %s');
$GLOBALS['TL_LANG']['tl_member']['copy'] = array('Duplikovat člena', 'Duplikovat člena ID %s');
$GLOBALS['TL_LANG']['tl_member']['delete'] = array('Smazat člena', 'Smazat člena ID %s');
$GLOBALS['TL_LANG']['tl_member']['toggle'] = array('Aktivovat / deaktivovat', 'Aktivovat / deaktivovat člena ID %s');

?>