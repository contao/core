<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['MOD']['content'] = 'Obsah';
$GLOBALS['TL_LANG']['MOD']['article'] = array('Články', 'Články jsou použity jako kontejner pro obsahové prvky jako text, obrázky nebo hyperlinky. Každý článek je publikován na určité stránce. Tento modul umožňuje spravovat vaše články.');
$GLOBALS['TL_LANG']['MOD']['form'] = array('Generátor formulářů', 'Tento modul umožňuje vytvořit jakýkoliv webový formulář.');
$GLOBALS['TL_LANG']['MOD']['design'] = 'Rozvržení';
$GLOBALS['TL_LANG']['MOD']['themes'] = array('Vzhled', 'Správa modulů, kaskádovitých stylů, rozvržení stránek a předloh frontendu.');
$GLOBALS['TL_LANG']['MOD']['css'] = array('Styly', 'Tvorba a úprava CSS.');
$GLOBALS['TL_LANG']['MOD']['modules'] = array('Moduly', 'Správa modulů ve frontendu webové stránky.');
$GLOBALS['TL_LANG']['MOD']['layout'] = array('Rozvržení stránek', 'Správa rozvržení stránek.');
$GLOBALS['TL_LANG']['MOD']['page'] = array('Struktura stránek', 'Tento modul umožňuje nastavit strukturu stránek Vaší webové stránky.');
$GLOBALS['TL_LANG']['MOD']['accounts'] = 'Manažer účtů';
$GLOBALS['TL_LANG']['MOD']['member'] = array('Členové', 'Správa členských účtů');
$GLOBALS['TL_LANG']['MOD']['mgroup'] = array('Skupiny členů', 'Tento modul umožňuje spravovat členské skupiny (uživatelské skupiny front-endu)');
$GLOBALS['TL_LANG']['MOD']['user'] = array('Uživatelé', 'Tento modul umožňuje správovat uživatelské účty (uživatelé backendu).');
$GLOBALS['TL_LANG']['MOD']['group'] = array('Skupiny uživatelů', 'Tento modul umožňuje spravovat uživatelské skupiny (uživatelské skupiny backendu)');
$GLOBALS['TL_LANG']['MOD']['system'] = 'Systém';
$GLOBALS['TL_LANG']['MOD']['files'] = array('Manažer souborů', 'Správa souborů a složek nebo nahrání nových souborů na server.');
$GLOBALS['TL_LANG']['MOD']['log'] = array('Systémové zprávy', 'Procházení systémových zpráv a analýza aktivity webové stránky.');
$GLOBALS['TL_LANG']['MOD']['settings'] = array('Nastavení', 'Nastavení a optimalizace Contao.');
$GLOBALS['TL_LANG']['MOD']['maintenance'] = array('Údržba systému', 'Údržba nebo aktualizace Contao.');
$GLOBALS['TL_LANG']['MOD']['profile'] = 'Uživatelské funkce';
$GLOBALS['TL_LANG']['MOD']['undo'] = array('Zpět', 'Obnovení smazaných záznamů.');
$GLOBALS['TL_LANG']['MOD']['login'] = array('Osobní data', 'Tento modul umožňuje změnit osobní údaje nebo nastavit nové heslo');

$GLOBALS['TL_LANG']['FMD']['navigationMenu'] = 'Navigace';
$GLOBALS['TL_LANG']['FMD']['navigation'] = array('Navigační menu', 'generuje navigační menu ze struktury stránek.');
$GLOBALS['TL_LANG']['FMD']['customnav'] = array('Vlastní navigace', 'generuje vlastní navigační menu.');
$GLOBALS['TL_LANG']['FMD']['breadcrumb'] = array('Drobečková navigace', 'vytvoří drobečkové navigační menu.');
$GLOBALS['TL_LANG']['FMD']['quicknav'] = array('Rychlá navigace', 'vytvoří rozbalovací menu ze struktury stránek.');
$GLOBALS['TL_LANG']['FMD']['quicklink'] = array('Rychlý odkaz', 'vytvoří vlastní rozbalovací menu.');
$GLOBALS['TL_LANG']['FMD']['booknav'] = array('Knižní navigace', 'vytvoří knižní navigaci.');
$GLOBALS['TL_LANG']['FMD']['articlenav'] = array('Navigace článků', 'vytvoří zlom stránky s navigací článků.');
$GLOBALS['TL_LANG']['FMD']['sitemap'] = array('Mapa stránek', 'Tento modul zobrazuje všechny dostupné stránky.');
$GLOBALS['TL_LANG']['FMD']['user'] = 'Uživatel';
$GLOBALS['TL_LANG']['FMD']['login'] = array('Přihlašovací formulář', 'generuje přihlašovací formulář.');
$GLOBALS['TL_LANG']['FMD']['logout'] = array('Automatické odhlášení', 'automaticky odhlásí uživatele.');
$GLOBALS['TL_LANG']['FMD']['personalData'] = array('Osobní data', 'generuje formulář pro editaci osobních dat užibatelů.');
$GLOBALS['TL_LANG']['FMD']['application'] = 'Aplikace';
$GLOBALS['TL_LANG']['FMD']['form'] = array('Formulář', 'přidá formulář na stránku.');
$GLOBALS['TL_LANG']['FMD']['search'] = array('Vyhledávač', 'přidá vyhledávací formulář na stránku.');
$GLOBALS['TL_LANG']['FMD']['articleList'] = array('Seznam článků', 'vygeneruje seznam článků daného sloupce');
$GLOBALS['TL_LANG']['FMD']['miscellaneous'] = 'Různé';
$GLOBALS['TL_LANG']['FMD']['html'] = array('Vlastní HTML kód', 'Tento modul dovoluje použít vlastní HTML kód.');
$GLOBALS['TL_LANG']['FMD']['flash'] = array('Flash video', 'vloží flashové video do stránky.');
$GLOBALS['TL_LANG']['FMD']['randomImage'] = array('Náhodný obrázek', 'Tento modul přidá do stránky náhodný obrázek.');

$GLOBALS['TL_LANG']['MOD']['registration'] = array('Registrace uživatele', 'Tento modul poskytuje pokročilejší funkce uživatelské registrace.');
$GLOBALS['TL_LANG']['FMD']['registration'] = array('Registrace člena', 'Tento modul vytváří formulář, který umožňuje front end uživatelům registraci na vašem webu.');
$GLOBALS['TL_LANG']['FMD']['lostPassword'] = array('Ztracené heslo', 'Tento modul vytváří formulář, který povoluje uživatelům požádat o nové heslo.');
$GLOBALS['TL_LANG']['FMD']['closeAccount'] = array('Zrušit účet', 'Smaže členský účet.');

$GLOBALS['TL_LANG']['MOD']['rss_reader'] = array('RSS čtečka', 'Import RSS.');
$GLOBALS['TL_LANG']['FMD']['rss_reader'] = array('RSS čtečka', 'Import RSS');

$GLOBALS['TL_LANG']['MOD']['tpl_editor'] = array('Šablony', 'Editace souborů šablon v backendu.');

?>