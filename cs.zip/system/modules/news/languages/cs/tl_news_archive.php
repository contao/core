<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_news_archive']['title'] = array('Název', 'Zadejte prosím název archivu novinek.');
$GLOBALS['TL_LANG']['tl_news_archive']['jumpTo'] = array('Přesměrovat na stránku', 'Zvolte prosím stránku, na níž má být návštěvník přesměrován po kliknutí na příslušný odkaz.');
$GLOBALS['TL_LANG']['tl_news_archive']['allowComments'] = array('Povolit vkládání komentářů', 'Povolit návštěvníkům vkládat komentáře.');
$GLOBALS['TL_LANG']['tl_news_archive']['notify'] = array('Zaslat upozornění', 'Zaslat upozornění, když někdo napíše komentář.');
$GLOBALS['TL_LANG']['tl_news_archive']['sortOrder'] = array('Třídit podle', 'Ve výchozích nastaveních jsou komentáře řazeny vzestupně, tzn. že začínají tím nejstarším.');
$GLOBALS['TL_LANG']['tl_news_archive']['perPage'] = array('Počet komentářů na stránku', 'Počet komentářů na stránku. Zadejte 0, chcete-li vypnout zalamování stránky.');
$GLOBALS['TL_LANG']['tl_news_archive']['moderate'] = array('Moderovat komentáře', 'Schválit komentáře před jejich zveřejněním na webové stránce.');
$GLOBALS['TL_LANG']['tl_news_archive']['bbcode'] = array('Povolit BBCode', 'Povolit návštěvníkům formátovat jejich komentáře pomoci BBCode.');
$GLOBALS['TL_LANG']['tl_news_archive']['requireLogin'] = array('Vyžadovat přihlášení pro přidání komentářů', 'Povolit zadání komentářů jen přihlášeným uživatelům.');
$GLOBALS['TL_LANG']['tl_news_archive']['disableCaptcha'] = array('Vypnout bezpečnostní otázku', 'Použít tuto možnost jen, když je přidávání komentářů povolené přihlášeným uživatelům. V jiném případě se nedoporučuje bezpečnostní otázku vypínat.');
$GLOBALS['TL_LANG']['tl_news_archive']['protected'] = array('Chránit archiv', 'Zobrazit archiv novinek jen stávajícím členům.');
$GLOBALS['TL_LANG']['tl_news_archive']['groups'] = array('Povolené skupiny členů', 'Těmto skupinám členů bude povolený přístup k novinkám v daném archivu.');
$GLOBALS['TL_LANG']['tl_news_archive']['makeFeed'] = array('Vytvořit záznamy pro RSS', 'Vytvořit záznamy pro RSS.');
$GLOBALS['TL_LANG']['tl_news_archive']['format'] = array('Formát záznamů RSS', 'Zvolte prosím formát záznamů RSS.');
$GLOBALS['TL_LANG']['tl_news_archive']['language'] = array('Jazyk záznamů RSS', 'Zadejte prosím zkratku jazyku podle mezinárodního standardu ISO-639 (např. <em>cs</em>).');
$GLOBALS['TL_LANG']['tl_news_archive']['source'] = array('Nastavení exportu', 'Zde můžete zvolit, co se má exportovat.');
$GLOBALS['TL_LANG']['tl_news_archive']['maxItems'] = array('Maximální počet příspěvků v RSS', 'Zde můžete omezit počet příspěvků v RSS. Zadejte 0, aby se zobrazily všechny příspěvky.');
$GLOBALS['TL_LANG']['tl_news_archive']['feedBase'] = array('Hlavní internetová stránka', 'Zadejte prosím hlavní adresu internetové stránky (např. <em>http://</em>).');
$GLOBALS['TL_LANG']['tl_news_archive']['alias'] = array('Alias RSS', 'Zde můžete uvést jednoznačný název souboru (bez přípony). Soubor XML se automaticky vytvoří v kořenovém adresáři TYPOlight, např. jako <em>nazev.xml</em>.');
$GLOBALS['TL_LANG']['tl_news_archive']['description'] = array('Popis záznamů RSS', 'Zadejte prosím krátký popis záznamů RSS.');
$GLOBALS['TL_LANG']['tl_news_archive']['tstamp'] = array('Změněno', 'Datum a čas poslední změny');
$GLOBALS['TL_LANG']['tl_news_archive']['title_legend'] = 'Název a stránka přesměrování';
$GLOBALS['TL_LANG']['tl_news_archive']['comments_legend'] = 'Komentáře';
$GLOBALS['TL_LANG']['tl_news_archive']['protected_legend'] = 'Chráněný přístup';
$GLOBALS['TL_LANG']['tl_news_archive']['feed_legend'] = 'Kanál RSS';
$GLOBALS['TL_LANG']['tl_news_archive']['notify_admin'] = 'Administrátor systému';
$GLOBALS['TL_LANG']['tl_news_archive']['notify_author'] = 'Autor novinky';
$GLOBALS['TL_LANG']['tl_news_archive']['notify_both'] = 'Autor a administrátor systému';
$GLOBALS['TL_LANG']['tl_news_archive']['source_teaser'] = 'Ukázka novinky';
$GLOBALS['TL_LANG']['tl_news_archive']['source_text'] = 'Plné znění';
$GLOBALS['TL_LANG']['tl_news_archive']['new'] = array('Nový archiv', 'Vytvořit nový archiv');
$GLOBALS['TL_LANG']['tl_news_archive']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k archivu ID %s');
$GLOBALS['TL_LANG']['tl_news_archive']['edit'] = array('Upravit archiv', 'Upravit archiv ID %s');
$GLOBALS['TL_LANG']['tl_news_archive']['editheader'] = array('Upravit nastavení archivu', 'Upravit nastavení archivu ID %s');
$GLOBALS['TL_LANG']['tl_news_archive']['copy'] = array('Duplikovat archiv', 'Duplikovat archiv ID %s');
$GLOBALS['TL_LANG']['tl_news_archive']['delete'] = array('Smazat archiv', 'Smazat archiv ID %s');
$GLOBALS['TL_LANG']['tl_news_archive']['comments'] = array('Komentáře', 'Zobrazit komentáře archivu ID %s');

?>