<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_news']['headline'] = array('Název', 'Zadejte prosím název novinky.');
$GLOBALS['TL_LANG']['tl_news']['alias'] = array('Alias novinky', 'Alias je jednoznačným odkazem na příslušný článek a lze ho použít místo ID.');
$GLOBALS['TL_LANG']['tl_news']['author'] = array('Autor', 'Zde můžete zadat autora novinky.');
$GLOBALS['TL_LANG']['tl_news']['date'] = array('Datum', 'Zadejte prosím datum podle globálně platných formátů.');
$GLOBALS['TL_LANG']['tl_news']['time'] = array('Čas', 'Zadejte prosím čas podle globálně platných formátů.');
$GLOBALS['TL_LANG']['tl_news']['subheadline'] = array('Podnadpis', 'Zde můžete zadat podnadpis.');
$GLOBALS['TL_LANG']['tl_news']['teaser'] = array('Ukázka novinky', 'Ukázka může být zobrazena místo celého článku na stránce, kde se vyskytuje víc novinek. Ten tak bude automaticky zobrazený ve zkrácené verzi a ukončen "čti dál…".');
$GLOBALS['TL_LANG']['tl_news']['text'] = array('Text novinky', 'Zde můžete zadat text pro novinku.');
$GLOBALS['TL_LANG']['tl_news']['addImage'] = array('Přidat obrázek', 'Přidat obrázek k novince.');
$GLOBALS['TL_LANG']['tl_news']['addEnclosure'] = array('Přidat přílohu/y', 'Přidat jeden nebo více souborů ke stažení.');
$GLOBALS['TL_LANG']['tl_news']['enclosure'] = array('Příloha/y', 'Vyberte prosím soubor, který chcete připojit.');
$GLOBALS['TL_LANG']['tl_news']['source'] = array('Cíl přesměrování', 'Zde můžete přepsat standardní přesměrování.');
$GLOBALS['TL_LANG']['tl_news']['default'] = array('Použít výchozí', 'Při kliknutí na odkaz "čti dál…" bude návštěvník přesměrován na výchozí stránku archivu novinek.');
$GLOBALS['TL_LANG']['tl_news']['internal'] = array('Propojit se stránkou', 'Při kliknutí na odkaz "čti dál…" bude návštěvník přesměrován na stránku.');
$GLOBALS['TL_LANG']['tl_news']['article'] = array('Propojit s článkem', 'Při kliknutí na odkaz "čti dál…" bude návštěvník přesměrován na tento článek.');
$GLOBALS['TL_LANG']['tl_news']['external'] = array('Odkázat na externí internetovou adresu', 'Při kliknutí na odkaz "čti dál…" bude návštěvník přesměrován na zadanou internetovou adresu.');
$GLOBALS['TL_LANG']['tl_news']['jumpTo'] = array('Přesměrování na stránku', 'Zvolte prosím stránku, na níž má být návštěvník přesměrován po kliknutí na příslušný odkaz.');
$GLOBALS['TL_LANG']['tl_news']['articleId'] = array('Článek', 'Zvolte prosím článek, na nejž má být návštěvník přesměrován po kliknutí na příslušný odkaz.');
$GLOBALS['TL_LANG']['tl_news']['cssClass'] = array('Třída CSS', 'Zde můžete zadat jednu nebo více tříd kaskádovitých stylů.');
$GLOBALS['TL_LANG']['tl_news']['noComments'] = array('Vypnout komentáře', 'Nepovolit vkládání komentářů pod novinky.');
$GLOBALS['TL_LANG']['tl_news']['featured'] = array('Zvýraznit příspěvek', 'Zobrazit příspěvek v seznamu zvýrazněných novinek.');
$GLOBALS['TL_LANG']['tl_news']['published'] = array('Publikovat', 'Zveřejnit příspěvek na webové stránce.');
$GLOBALS['TL_LANG']['tl_news']['start'] = array('Zobrazit od', 'Nezobrazovat novinku na webových stránkách před tímto dnem.');
$GLOBALS['TL_LANG']['tl_news']['stop'] = array('Zobrazit do', 'Nezobrazovat novinku na webových stránkách po tomto dni.');
$GLOBALS['TL_LANG']['tl_news']['title_legend'] = 'Název a autor';
$GLOBALS['TL_LANG']['tl_news']['date_legend'] = 'Datum a čas';
$GLOBALS['TL_LANG']['tl_news']['teaser_legend'] = 'Podnadpis a ukázka';
$GLOBALS['TL_LANG']['tl_news']['text_legend'] = 'Text novinky';
$GLOBALS['TL_LANG']['tl_news']['image_legend'] = 'Nastavení obrázku';
$GLOBALS['TL_LANG']['tl_news']['enclosure_legend'] = 'Příloha/y';
$GLOBALS['TL_LANG']['tl_news']['source_legend'] = 'Přesměrování';
$GLOBALS['TL_LANG']['tl_news']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_news']['publish_legend'] = 'Nastavení publikování';
$GLOBALS['TL_LANG']['tl_news']['new'] = array('Nový článek', 'Vytvořit nový článek novinek');
$GLOBALS['TL_LANG']['tl_news']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k článku ID %s');
$GLOBALS['TL_LANG']['tl_news']['edit'] = array('Upravit článek', 'Upravit článek ID %s');
$GLOBALS['TL_LANG']['tl_news']['copy'] = array('Duplikovat článek', 'Duplikovat článek ID %s');
$GLOBALS['TL_LANG']['tl_news']['cut'] = array('Přesunout článek', 'Přesunout článek ID %s');
$GLOBALS['TL_LANG']['tl_news']['delete'] = array('Smazat článek', 'Smazat článek ID %s');
$GLOBALS['TL_LANG']['tl_news']['toggle'] = array('Publikovat / nepublikovat článek', 'Publikovat / nepublikovat článek');
$GLOBALS['TL_LANG']['tl_news']['feature'] = array('Zvýraznit/zrušit zvýraznění příspěvku', 'Zvýraznit/zrušit zvýraznění příspěvku ID %s');
$GLOBALS['TL_LANG']['tl_news']['editheader'] = array('Upravit nastavení achvivu', 'Upravit nastavení archivu');
$GLOBALS['TL_LANG']['tl_news']['pasteafter'] = array('Vložit do tohto archivu', 'Vložit za článek novinky ID %s');

?>