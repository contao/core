<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_newsletter_channel']['title'] = array('Název', 'Zadejte prosím název distribuce Zpravodajů.');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['jumpTo'] = array('Stránka přesměrování', 'Vyberte prosím stránku, na níž se nachází Zpravodaj, aby na ní mohl být přesměrován návštěvník po kliknutí na příslušný odkaz.');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['useSMTP'] = array('Vlastní server SMTP', 'Použít vlastní server SMTP pro rozeslání Zpravodajů.');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['smtpHost'] = array('Hostitel SMTP', 'Zadejte prosím jméno hostitele SMTP.');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['smtpUser'] = array('Uživatelské jméno SMTP', 'Zadejte prosím uživatelské jméno SMTP.');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['smtpPass'] = array('Heslo SMTP', 'Zadejte prosím Vaše heslo pro SMTP.');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['smtpEnc'] = array('Zabezpečení SMTP', 'Zde můžete zvolit metodu zabezpečení přenosu (SSL nebo TLS).');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['smtpPort'] = array('Číslo portu SMTP', 'Zadejte prosím číslo portu serveru SMTP.');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['tstamp'] = array('Změněno', 'Datum a čas poslední změny.');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['title_legend'] = 'Název a Přesměrování';
$GLOBALS['TL_LANG']['tl_newsletter_channel']['smtp_legend'] = 'Nastavení SMTP';
$GLOBALS['TL_LANG']['tl_newsletter_channel']['new'] = array('Nová distribuce Zpravodaje', 'Vytvořit novou distribuci.');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti k distribuci ID %s');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['edit'] = array('Upravit distribuci', 'Upravit distribuci ID %s');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['editheader'] = array('Upravit nastavení distribuce', 'Upravit nastavení distribuce ID %s');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['copy'] = array('Duplikovat distribuci', 'Duplikovat distribuci ID %s');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['delete'] = array('Smazat distribuci', 'Smazat distribuci ID %s');
$GLOBALS['TL_LANG']['tl_newsletter_channel']['recipients'] = array('Upravit příjemce', 'Upravit příjemce distribuce ID %s');

?>