<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

/**
 * Contao Open Source CMS
 * Copyright (C) 2005-2012 Leo Feyer
 *
 * Formerly known as TYPOlight Open Source CMS.
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, please visit the Free
 * Software Foundation website at <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Jan Kout 2010 − 2012
 * @copyright  Daniel Gajdos  2009 - 2012
 * @copyright  Tomas Petrlik 2010 - 2012
 * @copyright  Jiri Bartos 2008 - 2009
 * @copyright  Jiri Sedlacek  2009
 * @copyright  Zdenek Hejl 2010
 * @author     Jan Kout <koutjan@gmail.com>
 * @author     Daniel Gajdos <mail@danielarts.com>
 * @author     Tomas Petrlik <frogzone@frogzone.cz>
 * @author     Jiri Bartos <yurybury@gmail.com>
 * @author     Jiri Sedlacek <jiri@sedlackovi.cz>
 * @author     Jiri Krcmar <atronoss@gmail.com>
 * @author     Zdenek Hejl <zdenek@zdenek-hejl.com>
 * @package    Czech
 * @license    LGPL
 * @filesource
 */

$GLOBALS['TL_LANG']['tl_newsletter']['subject'] = array('Předmět', 'Zadejte prosím předmět zpravodaje.');
$GLOBALS['TL_LANG']['tl_newsletter']['alias'] = array('Alias zpravodaje', 'Alias zpravodaje je jednoznačný odkaz, který může být použitý namísto čísla ID zpravodaje.');
$GLOBALS['TL_LANG']['tl_newsletter']['content'] = array('Obsah v HTML', 'Zde můžete zadat obsah v HTML Vašeho Zpravodaje. Použijte link <em>##email##</em> pro vložení mailové adresy příjemce.');
$GLOBALS['TL_LANG']['tl_newsletter']['text'] = array('Textový obsah', 'Zde můžete zadat textový obsah Vašeho Zpravodaje. Použijte link <em>##email##</em> pro vložení mailové adresy příjemce.');
$GLOBALS['TL_LANG']['tl_newsletter']['addFile'] = array('Přidat přílohy', 'Přidejte jednu nebo více příloh ke Zpravodaji.');
$GLOBALS['TL_LANG']['tl_newsletter']['files'] = array('Přílohy', 'Vyberte prosím soubory, které chcete připojit k Vašemu zpravodaji a které mají být načteny z adresáře souborů.');
$GLOBALS['TL_LANG']['tl_newsletter']['template'] = array('Předloha e-mailu', 'Zde můžete zvolit předlohu e-mailu.');
$GLOBALS['TL_LANG']['tl_newsletter']['sendText'] = array('Zaslat jako neformátovaný text', 'Zaslat Zpravodaje jak nenaformátovaný text, tzn. bez použití znaků HTML.');
$GLOBALS['TL_LANG']['tl_newsletter']['externalImages'] = array('Externí obrázky', 'Nevkládat obrázky v HTML zpravodaji.');
$GLOBALS['TL_LANG']['tl_newsletter']['senderName'] = array('Jméno odesílatele', 'Zde můžete uvést jméno odesílatele.');
$GLOBALS['TL_LANG']['tl_newsletter']['sender'] = array('Mailová adresa odesílatele', 'Zde můžete zadat mailovou adresu odesílatele.');
$GLOBALS['TL_LANG']['tl_newsletter']['mailsPerCycle'] = array('Cykly rozeslání mailů', 'Rozeslání mailů proběhne v několika krocích, aby nedošlo k přerušení.');
$GLOBALS['TL_LANG']['tl_newsletter']['timeout'] = array('Čekací doba v sekundách', 'Zde můžete nastavit čekací dobu mezi cykly rozesílání mailů, abyste mohli kontroloval počet odeslaných mailů za minutu.');
$GLOBALS['TL_LANG']['tl_newsletter']['start'] = array('Začátek nového cyklu odesílání', 'V případě, že je přerušen proces odesílání, můžete zde uvést číslo s posledním příjemcem, po kterém se má začít opětovné odesílání. Můžete zkontrolovat, kolik zpráv bylo odesláno v <em>system/logs/newsletter_*.log</em> souboru. Např. bylo odesláno 120 zpráv, zadejte 120, aby se pokračovalo 121 příjemcem (začíná se 0 pro první cyklus).');
$GLOBALS['TL_LANG']['tl_newsletter']['sendPreviewTo'] = array('Testovací mail odeslat na', 'Odeslat testovací mail se Zpravodajem na tuto mailovou adresu.');
$GLOBALS['TL_LANG']['tl_newsletter']['title_legend'] = 'Název a předmět';
$GLOBALS['TL_LANG']['tl_newsletter']['html_legend'] = 'Obsah HTML';
$GLOBALS['TL_LANG']['tl_newsletter']['text_legend'] = 'Text';
$GLOBALS['TL_LANG']['tl_newsletter']['attachment_legend'] = 'Přílohy';
$GLOBALS['TL_LANG']['tl_newsletter']['template_legend'] = 'Nastavení předlohy';
$GLOBALS['TL_LANG']['tl_newsletter']['expert_legend'] = 'Rozšířená nastavení';
$GLOBALS['TL_LANG']['tl_newsletter']['sent'] = 'Posláno';
$GLOBALS['TL_LANG']['tl_newsletter']['sentOn'] = 'Posláno %s';
$GLOBALS['TL_LANG']['tl_newsletter']['notSent'] = 'Ještě neodesláno';
$GLOBALS['TL_LANG']['tl_newsletter']['mailingDate'] = 'Datum odeslání';
$GLOBALS['TL_LANG']['tl_newsletter']['confirm'] = 'Zpravodaj byl rozeslán %s příjemcům.';
$GLOBALS['TL_LANG']['tl_newsletter']['rejected'] = '%s neplatné mailové adresy byly deaktivovány.';
$GLOBALS['TL_LANG']['tl_newsletter']['error'] = 'Neexistuje žádný odebíratel pro tento Zpravodaj.';
$GLOBALS['TL_LANG']['tl_newsletter']['from'] = 'Formulář';
$GLOBALS['TL_LANG']['tl_newsletter']['attachments'] = 'Přílohy';
$GLOBALS['TL_LANG']['tl_newsletter']['preview'] = 'Testovací mail';
$GLOBALS['TL_LANG']['tl_newsletter']['sendConfirm'] = 'Chcete opravdu odeslat tento Zpravodaj?';
$GLOBALS['TL_LANG']['tl_newsletter']['new'] = array('Nový zpravodaj', 'Vytvoří nový zpravodaj.');
$GLOBALS['TL_LANG']['tl_newsletter']['show'] = array('Zobrazit podrobnosti', 'Zobrazit podrobnosti ke zpravoji ID %s');
$GLOBALS['TL_LANG']['tl_newsletter']['edit'] = array('Upravit zpravodaj', 'Upraví zpravodaje ID %s');
$GLOBALS['TL_LANG']['tl_newsletter']['copy'] = array('Kopírovat zpravodaj', 'Zkopíruje zpravodaje ID %s');
$GLOBALS['TL_LANG']['tl_newsletter']['cut'] = array('Přesunout zpravodaj', 'Přesune zpravodaje ID %s');
$GLOBALS['TL_LANG']['tl_newsletter']['delete'] = array('Smazat zpravodaj', 'Smaže zpravodaje ID %s');
$GLOBALS['TL_LANG']['tl_newsletter']['editheader'] = array('Upravit distribuci', 'Upraví nastavení distribuce');
$GLOBALS['TL_LANG']['tl_newsletter']['pasteafter'] = array('Vložit do této distribuce', 'Vložit za zpravodaj ID %s');
$GLOBALS['TL_LANG']['tl_newsletter']['send'] = array('Poslat zpravodaj', 'Rozešle zpravodaj %s');

?>